# GeoSafe SQL package — direct correction notes

This package was edited from the uploaded `database (2).zip`. No SQL was executed and no MySQL database was accessed.

## Files changed
- `database/geosafe_db_schema.sql`
- `database/migrations/002_family_qr_membership.sql`
- `database/migrations/003_backend_compatibility_and_users.sql`
- `database/migrations/004_incident_assignment_and_notes.sql`
- `database/migrations/008_security_audit_and_emergency_broadcasts.sql`
- `database/verify_database.sql`

## Corrections made
1. New family-group records require both a nonblank house/building number and street. The fresh schema and Migration 002 table definition use NOT NULL plus a CHECK constraint; the Migration 002 insert trigger rejects incomplete new inserts while allowing pre-existing incomplete rows in already-created databases to remain visible for manual review.
2. Family membership remains authoritative in `family_members`. The redundant `users.family_group_id` is retained only as a deprecated compatibility cache because the Node.js backend was not included. Migration 003 now ensures its foreign key exists and no longer uses a user-settable MySQL session variable as a security boundary. Backend authorization must never trust this cache.
3. Incident matching in Migration 004 now compares all migrated business fields using NULL-safe comparisons. A reference-number collision is accepted only when all mapped fields match. A full-field post-copy reconciliation runs before child foreign-key repointing.
4. Migration 004 comments now explicitly acknowledge that MySQL DDL implicitly commits and that an interrupted run is not transactionally rolled back. A verified backup and manual checkpoint review are required.
5. Audit/history tables now reject UPDATE as well as DELETE, making the database-side trigger behavior consistent with the intended immutable-history policy. Database privileges must also be restricted.
19. Verification now treats any missing/blank house number or street as an incomplete family address rather than incorrectly allowing both to be NULL. Its trigger inventory also checks all six new audit UPDATE-protection triggers (27 triggers total), and Section 1.4 expects `IS_NULLABLE = 'NO'` on `family_groups.house_number` and `family_groups.street` to match the fresh schema and Migration 002.
20. `geosafe_db_schema.sql` now binds `fk_users_family_group` (`users.family_group_id -> family_groups.id ON DELETE RESTRICT`) immediately after `family_groups` is created so a fresh schema installation has all 51 foreign keys verified by `verify_database.sql`.
21. Migration 002 now includes `chk_family_address_complete` and `chk_family_fixed_location` on `family_groups`, and Migration 004 Section 8 uses the same 17-column NULL-safe (`<=>`) comparison as step 6.4b.
22. Backend (`familyRoutes.js`, `familyController.js`, `adminController.js`, `userController.js`, `userModel.js`) and frontend (`family.html`, `assets/js/family.js`, `assets/js/store.js`) are synchronized with `role_id`, authoritative `family_members`, and mandatory `house_number` + `street` on family creation.

## Important limitations / manual review still required
- The Node.js backend source was not included in the ZIP. Backend queries, role handling, family membership flows, and API authorization were therefore not modified or verified. Update the backend to use `role_id` and `family_members`; treat `users.family_group_id` as deprecated only.
- The incident migration contains DDL (DROP/ADD FOREIGN KEY) that MySQL implicitly commits. Do not assume a transaction can roll it back. Take and verify a full backup before migration. If Migration 004 is interrupted after a foreign key is dropped, stop and inspect the affected child table and mapping table before rerunning.
- The scripts were statically inspected and edited but were not executed against MySQL 8.4. Runtime compatibility, existing-database data conflicts, and trigger interactions still require testing on a disposable copy of the database first.
- The package still includes both `reports` and the frozen legacy `incident_reports` table intentionally. The latter must not be dropped until the application has been migrated and reconciliation has been confirmed.
- Existing family groups with missing/blank addresses are not fabricated or automatically rewritten. Verification will flag them for manual completion.
