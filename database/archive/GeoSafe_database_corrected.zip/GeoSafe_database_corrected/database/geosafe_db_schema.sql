-- ============================================================================
-- GeoSafe Emergency Assistance & Disaster Reporting System
-- Database Schema Definition: geosafe_db
-- Target Server: MySQL Community Server 8.0+ / 8.4 LTS
-- Character Set: utf8mb4, Collation: utf8mb4_unicode_ci
-- ============================================================================

CREATE DATABASE IF NOT EXISTS geosafe_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE geosafe_db;

-- ----------------------------------------------------------------------------
-- MODULE 1: AUTHENTICATION, ROLES & USER ACCOUNTS
-- ----------------------------------------------------------------------------

-- 1.1 Roles Definition Table (Authoritative System Roles: Exactly 3)
CREATE TABLE IF NOT EXISTS roles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE,
  description VARCHAR(255) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 1.2 Core Users Table
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  contact_number VARCHAR(35) DEFAULT NULL,
  address VARCHAR(255) DEFAULT NULL,
  safety_status ENUM('safe', 'need_help', 'injured', 'no_response') NOT NULL DEFAULT 'no_response',
  last_latitude DECIMAL(10, 8) DEFAULT NULL,
  last_longitude DECIMAL(11, 8) DEFAULT NULL,
  battery_level TINYINT UNSIGNED DEFAULT NULL,
  family_group_id INT DEFAULT NULL,
  password_hash VARCHAR(255) NOT NULL,
  reset_token_hash VARCHAR(64) DEFAULT NULL,
  reset_token_expires_at TIMESTAMP NULL DEFAULT NULL,
  role_id INT NOT NULL,
  role ENUM('admin', 'responder', 'resident') DEFAULT NULL,
  status ENUM('active', 'inactive', 'suspended') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_users_email (email),
  INDEX idx_users_role_id (role_id),
  INDEX idx_users_role (role),
  INDEX idx_users_status (status),
  INDEX idx_users_safety (safety_status),
  INDEX idx_users_family (family_group_id),
  INDEX idx_users_reset_token (reset_token_hash),
  CONSTRAINT fk_users_role FOREIGN KEY (role_id) REFERENCES roles(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 1.3 Extended Resident Profiles Table
-- (Zero fabricated location defaults: fields default to NULL until entered by resident)
CREATE TABLE IF NOT EXISTS user_profiles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  first_name VARCHAR(60) NOT NULL,
  last_name VARCHAR(60) NOT NULL,
  phone VARCHAR(30) DEFAULT NULL,
  street_address VARCHAR(200) DEFAULT NULL,
  barangay VARCHAR(100) DEFAULT NULL,
  city VARCHAR(100) DEFAULT NULL,
  province VARCHAR(100) DEFAULT NULL,
  postal_code VARCHAR(10) DEFAULT NULL,
  emergency_contact_name VARCHAR(120) DEFAULT NULL,
  emergency_contact_phone VARCHAR(30) DEFAULT NULL,
  emergency_contact_relation VARCHAR(60) DEFAULT NULL,
  medical_notes TEXT DEFAULT NULL,
  verification_status ENUM('Verified Resident', 'Unverified Resident', 'Pending Review') NOT NULL DEFAULT 'Unverified Resident',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_user_profiles_user (user_id),
  CONSTRAINT fk_user_profiles_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 1.4 Extended Responder Profiles Table
-- (Zero fabricated department, unit, or rank defaults: assigned explicitly by administrators)
CREATE TABLE IF NOT EXISTS responder_profiles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  badge_number VARCHAR(50) NOT NULL UNIQUE,
  callsign VARCHAR(60) DEFAULT NULL,
  department VARCHAR(120) DEFAULT NULL,
  assigned_unit VARCHAR(120) DEFAULT NULL,
  rank_title VARCHAR(80) DEFAULT NULL,
  availability_status ENUM('On Duty', 'Unavailable', 'Off Duty') NOT NULL DEFAULT 'Off Duty',
  vehicle_info VARCHAR(120) DEFAULT NULL,
  specialized_skills TEXT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_responder_profiles_user (user_id),
  INDEX idx_responder_availability (availability_status),
  CONSTRAINT fk_responder_profiles_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- MODULE 2: INCIDENT REPORTING & MANAGEMENT
-- ----------------------------------------------------------------------------

-- 2.1 Incident Categories Table
CREATE TABLE IF NOT EXISTS incident_categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  description VARCHAR(255) DEFAULT NULL,
  default_severity ENUM('Low', 'Medium', 'High', 'Critical') NOT NULL DEFAULT 'Medium',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.2 Canonical Reports Table (Single Authoritative Incident Table for All Portals)
CREATE TABLE IF NOT EXISTS reports (
  id INT AUTO_INCREMENT PRIMARY KEY,
  reference_number VARCHAR(40) DEFAULT NULL UNIQUE,
  user_id INT NOT NULL,
  category_id INT DEFAULT NULL,
  incident_type VARCHAR(100) NOT NULL,
  title VARCHAR(180) DEFAULT NULL,
  description TEXT NOT NULL,
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  address VARCHAR(255) DEFAULT NULL,
  severity ENUM('low', 'medium', 'high', 'critical') NOT NULL DEFAULT 'medium',
  status ENUM('pending', 'verified', 'responding', 'on_site', 'resolved', 'dismissed') NOT NULL DEFAULT 'pending',
  assigned_to INT DEFAULT NULL,
  verified_by INT DEFAULT NULL,
  verified_at TIMESTAMP NULL DEFAULT NULL,
  resolved_at TIMESTAMP NULL DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_reports_ref (reference_number),
  INDEX idx_reports_user (user_id),
  INDEX idx_reports_category (category_id),
  INDEX idx_reports_status (status),
  INDEX idx_reports_severity (severity),
  INDEX idx_reports_assigned_to (assigned_to),
  INDEX idx_reports_created (created_at),
  INDEX idx_reports_coords (latitude, longitude),
  CONSTRAINT fk_reports_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_reports_category FOREIGN KEY (category_id) REFERENCES incident_categories(id) ON DELETE RESTRICT,
  CONSTRAINT fk_reports_assigned FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_reports_verifier FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.3 LEGACY Incident Reports Table (DEPRECATED, READ-ONLY after Migration 004)
-- Not an operational table. All portals read/write `reports`. Migration 004 freezes
-- this table with reject-write triggers; it is retained only until migration is verified.
CREATE TABLE IF NOT EXISTS incident_reports (
  id INT AUTO_INCREMENT PRIMARY KEY,
  reference_number VARCHAR(40) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  category_id INT NOT NULL,
  incident_type VARCHAR(100) DEFAULT NULL,
  title VARCHAR(180) NOT NULL,
  description TEXT NOT NULL,
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  address VARCHAR(255) NOT NULL,
  severity ENUM('Low', 'Medium', 'High', 'Critical') NOT NULL DEFAULT 'Medium',
  status ENUM('Pending', 'Verified', 'Responding', 'On Scene', 'Resolved', 'Dismissed') NOT NULL DEFAULT 'Pending',
  verified_by INT DEFAULT NULL,
  verified_at TIMESTAMP NULL DEFAULT NULL,
  resolved_at TIMESTAMP NULL DEFAULT NULL,
  assigned_to INT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_incidents_ref (reference_number),
  INDEX idx_incidents_status (status),
  INDEX idx_incidents_severity (severity),
  INDEX idx_incidents_created (created_at),
  INDEX idx_incidents_coords (latitude, longitude),
  INDEX idx_incidents_assigned (assigned_to),
  CONSTRAINT fk_incidents_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_incidents_category FOREIGN KEY (category_id) REFERENCES incident_categories(id) ON DELETE RESTRICT,
  CONSTRAINT fk_incidents_verifier FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_incidents_assigned_to FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.4 Incident Attachments Table (Authoritative Canonical Incident Link)
CREATE TABLE IF NOT EXISTS incident_attachments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  incident_id INT NOT NULL,
  file_url VARCHAR(255) NOT NULL,
  file_name VARCHAR(150) NOT NULL,
  file_type VARCHAR(50) DEFAULT NULL,
  file_size INT UNSIGNED DEFAULT NULL,
  uploaded_by INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_incident_attachments_incident (incident_id),
  CONSTRAINT fk_incident_attachments_incident FOREIGN KEY (incident_id) REFERENCES reports(id) ON DELETE RESTRICT,
  CONSTRAINT fk_incident_attachments_uploader FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.5 Incident Status Audit History Table (Restricted Deletion: Never Silently Erase Audit Trail)
CREATE TABLE IF NOT EXISTS incident_status_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  incident_id INT NOT NULL,
  previous_status VARCHAR(40) DEFAULT NULL,
  new_status VARCHAR(40) NOT NULL,
  changed_by INT NOT NULL,
  notes TEXT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_incident_history_incident (incident_id),
  CONSTRAINT fk_incident_history_incident FOREIGN KEY (incident_id) REFERENCES reports(id) ON DELETE RESTRICT,
  CONSTRAINT fk_incident_history_changer FOREIGN KEY (changed_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- MODULE 3: RESCUE REQUESTS & DISPATCH MANAGEMENT
-- ----------------------------------------------------------------------------

-- 3.1 Rescue Requests Table
-- (Priority must be explicitly established; no arbitrary 'Critical' default)
CREATE TABLE IF NOT EXISTS rescue_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  reference_number VARCHAR(40) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  emergency_condition VARCHAR(120) NOT NULL,
  people_trapped INT UNSIGNED NOT NULL DEFAULT 1,
  description TEXT NOT NULL,
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  address VARCHAR(255) NOT NULL,
  landmark VARCHAR(180) DEFAULT NULL,
  access_notes TEXT DEFAULT NULL,
  priority ENUM('Critical', 'High', 'Medium', 'Low') NOT NULL,
  status ENUM('Pending Dispatch', 'Assigned', 'En Route', 'On Scene', 'Completed', 'Cancelled') NOT NULL DEFAULT 'Pending Dispatch',
  confirmed_resolved_at TIMESTAMP NULL DEFAULT NULL,
  resident_confirmed_at TIMESTAMP NULL DEFAULT NULL,
  confirmed_by INT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_rescue_ref (reference_number),
  INDEX idx_rescue_status (status),
  INDEX idx_rescue_priority (priority),
  INDEX idx_rescue_created (created_at),
  INDEX idx_rescue_coords (latitude, longitude),
  CONSTRAINT fk_rescue_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_rescue_confirmed_by FOREIGN KEY (confirmed_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3.2 Rescue Assignments Table
CREATE TABLE IF NOT EXISTS rescue_assignments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  rescue_id INT NOT NULL,
  responder_user_id INT NOT NULL,
  assigned_by INT NOT NULL,
  dispatch_instructions TEXT DEFAULT NULL,
  status ENUM('Assigned', 'Accepted', 'En Route', 'On Scene', 'Completed') NOT NULL DEFAULT 'Assigned',
  assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  accepted_at TIMESTAMP NULL DEFAULT NULL,
  completed_at TIMESTAMP NULL DEFAULT NULL,
  INDEX idx_rescue_assign_rescue (rescue_id),
  INDEX idx_rescue_assign_responder (responder_user_id),
  CONSTRAINT fk_rescue_assign_rescue FOREIGN KEY (rescue_id) REFERENCES rescue_requests(id) ON DELETE RESTRICT,
  CONSTRAINT fk_rescue_assign_responder FOREIGN KEY (responder_user_id) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_rescue_assign_dispatcher FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3.3 Rescue Status History Table
CREATE TABLE IF NOT EXISTS rescue_status_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  rescue_id INT NOT NULL,
  previous_status VARCHAR(40) DEFAULT NULL,
  new_status VARCHAR(40) NOT NULL,
  changed_by INT NOT NULL,
  notes TEXT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_rescue_history_rescue (rescue_id),
  CONSTRAINT fk_rescue_history_rescue FOREIGN KEY (rescue_id) REFERENCES rescue_requests(id) ON DELETE RESTRICT,
  CONSTRAINT fk_rescue_history_changer FOREIGN KEY (changed_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3.4 Responder Assignment History Table (Audit Log)
CREATE TABLE IF NOT EXISTS responder_assignment_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  responder_user_id INT NOT NULL,
  rescue_id INT DEFAULT NULL,
  incident_id INT DEFAULT NULL,
  action VARCHAR(80) NOT NULL,
  details TEXT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_responder_history_resp (responder_user_id),
  CONSTRAINT fk_resp_hist_responder FOREIGN KEY (responder_user_id) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_resp_hist_rescue FOREIGN KEY (rescue_id) REFERENCES rescue_requests(id) ON DELETE RESTRICT,
  CONSTRAINT fk_resp_hist_incident FOREIGN KEY (incident_id) REFERENCES reports(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- MODULE 4: EVACUATION HAVENS & FACILITY MANAGEMENT
-- ----------------------------------------------------------------------------

-- 4.1 Evacuation Centers Table
-- (Capacities are verified upon facility inspection; no fabricated default numbers)
CREATE TABLE IF NOT EXISTS evacuation_centers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL UNIQUE,
  address VARCHAR(255) NOT NULL,
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  total_capacity INT UNSIGNED NOT NULL,
  capacity INT UNSIGNED NOT NULL,
  current_occupancy INT UNSIGNED NOT NULL DEFAULT 0,
  available_slots INT UNSIGNED NOT NULL,
  status ENUM('Open', 'Full', 'Closed', 'Standby') NOT NULL DEFAULT 'Standby',
  contact_person VARCHAR(120) DEFAULT NULL,
  contact_phone VARCHAR(40) DEFAULT NULL,
  contact_number VARCHAR(40) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_evac_status (status),
  INDEX idx_evac_coords (latitude, longitude)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4.2 Evacuation Center Facilities Table
-- (Restricted delete on center: facilities are preserved; centers use status = 'Closed')
CREATE TABLE IF NOT EXISTS evacuation_center_facilities (
  id INT AUTO_INCREMENT PRIMARY KEY,
  center_id INT NOT NULL,
  facility_name VARCHAR(100) NOT NULL,
  description VARCHAR(255) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_evac_fac_center (center_id),
  CONSTRAINT fk_evac_fac_center FOREIGN KEY (center_id) REFERENCES evacuation_centers(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- MODULE 5: FAMILY SAFETY TRACKER & QR MEMBERSHIP MANAGEMENT
-- ----------------------------------------------------------------------------

-- 5.1 Family Groups Table (Fixed Coverage: Barangay Bayanan, Muntinlupa City)
CREATE TABLE IF NOT EXISTS family_groups (
  id INT AUTO_INCREMENT PRIMARY KEY,
  family_name VARCHAR(120) NOT NULL,
  name VARCHAR(120) GENERATED ALWAYS AS (family_name) VIRTUAL,
  created_by INT NOT NULL,
  house_number VARCHAR(50) NOT NULL,
  street VARCHAR(150) NOT NULL,
  barangay VARCHAR(80) NOT NULL DEFAULT 'Bayanan',
  city VARCHAR(80) NOT NULL DEFAULT 'Muntinlupa City',
  province VARCHAR(80) NOT NULL DEFAULT 'Metro Manila',
  region VARCHAR(80) NOT NULL DEFAULT 'National Capital Region',
  country VARCHAR(80) NOT NULL DEFAULT 'Philippines',
  subdivision_purok VARCHAR(100) DEFAULT NULL,
  status ENUM('active', 'archived') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_family_groups_creator (created_by),
  INDEX idx_family_groups_status (status),
  INDEX idx_family_groups_location (barangay, city),
  CONSTRAINT chk_family_address_complete CHECK (
    house_number IS NOT NULL AND street IS NOT NULL
    AND CHAR_LENGTH(TRIM(house_number)) > 0
    AND CHAR_LENGTH(TRIM(street)) > 0
  ),
  CONSTRAINT chk_family_fixed_location CHECK (barangay = 'Bayanan' AND city = 'Muntinlupa City'),
  CONSTRAINT fk_family_groups_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bind legacy users.family_group_id cache to family_groups(id) with ON DELETE RESTRICT
SET @fk_users_fg_exists := (SELECT COUNT(*) FROM information_schema.REFERENTIAL_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'users'
    AND CONSTRAINT_NAME = 'fk_users_family_group');
SET @stmt_users_fg := IF(@fk_users_fg_exists = 0,
  'ALTER TABLE users ADD CONSTRAINT fk_users_family_group FOREIGN KEY (family_group_id) REFERENCES family_groups(id) ON DELETE RESTRICT ON UPDATE CASCADE',
  'SELECT "Foreign key fk_users_family_group already exists" AS status');
PREPARE stmt_users_fg FROM @stmt_users_fg;
EXECUTE stmt_users_fg;
DEALLOCATE PREPARE stmt_users_fg;

-- 5.2 Family Members Table (Authoritative Family Relationship: Strictly One Active Family per User)
CREATE TABLE IF NOT EXISTS family_members (
  id INT AUTO_INCREMENT PRIMARY KEY,
  family_id INT NOT NULL,
  user_id INT NOT NULL,
  relationship VARCHAR(60) NOT NULL DEFAULT 'Member',
  membership_role ENUM('manager', 'member') NOT NULL DEFAULT 'member',
  membership_status ENUM('active', 'inactive', 'removed') NOT NULL DEFAULT 'active',
  joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  active_user_id INT GENERATED ALWAYS AS (CASE WHEN membership_status = 'active' THEN user_id ELSE NULL END) STORED,
  UNIQUE KEY uq_active_family_user (active_user_id),
  UNIQUE KEY uq_family_user_member (family_id, user_id),
  INDEX idx_family_members_user (user_id),
  INDEX idx_family_members_status (membership_status),
  CONSTRAINT fk_family_members_family FOREIGN KEY (family_id) REFERENCES family_groups(id) ON DELETE RESTRICT,
  CONSTRAINT fk_family_members_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5.3 Family Invitations Table (Hashed Secure Token Storage - Never Raw Secrets)
CREATE TABLE IF NOT EXISTS family_invitations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  family_id INT NOT NULL,
  token_hash VARCHAR(64) NOT NULL UNIQUE,
  created_by INT NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  revoked_at TIMESTAMP NULL DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_family_inv_hash (token_hash),
  INDEX idx_family_inv_family (family_id),
  INDEX idx_family_inv_expires (expires_at),
  CONSTRAINT chk_family_inv_token_sha256 CHECK (
    CHAR_LENGTH(token_hash) = 64 AND token_hash REGEXP '^[0-9a-fA-F]{64}$'
  ),
  CONSTRAINT fk_family_inv_family FOREIGN KEY (family_id) REFERENCES family_groups(id) ON DELETE RESTRICT,
  CONSTRAINT fk_family_inv_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5.4 Family Join Requests Table (Manager Approval Workflow)
CREATE TABLE IF NOT EXISTS family_join_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  family_id INT NOT NULL,
  user_id INT NOT NULL,
  invitation_id INT NOT NULL,
  relationship VARCHAR(60) NOT NULL DEFAULT 'Member',
  request_status ENUM('pending', 'approved', 'rejected', 'cancelled') NOT NULL DEFAULT 'pending',
  requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  reviewed_by INT NULL DEFAULT NULL,
  reviewed_at TIMESTAMP NULL DEFAULT NULL,
  INDEX idx_join_req_family (family_id),
  INDEX idx_join_req_user (user_id),
  INDEX idx_join_req_status (request_status),
  CONSTRAINT fk_join_req_family FOREIGN KEY (family_id) REFERENCES family_groups(id) ON DELETE RESTRICT,
  CONSTRAINT fk_join_req_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_join_req_invitation FOREIGN KEY (invitation_id) REFERENCES family_invitations(id) ON DELETE RESTRICT,
  CONSTRAINT fk_join_req_reviewer FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5.5 Location Sharing Consents Table (Strictly Explicit, User-Granted & Revocable)
CREATE TABLE IF NOT EXISTS family_location_sharing_consents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  family_member_id INT NOT NULL UNIQUE,
  sharing_enabled TINYINT(1) NOT NULL DEFAULT 0,
  consented_at TIMESTAMP NULL DEFAULT NULL,
  revoked_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_fam_consent_member (family_member_id),
  CONSTRAINT chk_family_consent_timestamp CHECK (
    sharing_enabled = 0 OR consented_at IS NOT NULL
  ),
  CONSTRAINT fk_fam_consent_member FOREIGN KEY (family_member_id) REFERENCES family_members(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5.6 Family Member Location Updates Table
-- (Restricted delete on member: location records preserved for emergency search & rescue)
CREATE TABLE IF NOT EXISTS family_location_updates (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  family_member_id INT NOT NULL,
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  battery_level TINYINT UNSIGNED DEFAULT NULL,
  safety_status ENUM('safe', 'need_help', 'injured', 'no_response') NOT NULL DEFAULT 'no_response',
  recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_fam_loc_member_time (family_member_id, recorded_at),
  CONSTRAINT fk_fam_loc_member FOREIGN KEY (family_member_id) REFERENCES family_members(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- MODULE 6: NOTIFICATIONS & EMERGENCY BROADCASTS
-- ----------------------------------------------------------------------------

-- 6.1 Notifications Master Table
CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  message TEXT NOT NULL,
  severity ENUM('Low', 'Medium', 'High', 'Critical') NOT NULL DEFAULT 'Medium',
  category ENUM('Alert', 'Dispatch', 'General', 'Weather') NOT NULL DEFAULT 'Alert',
  created_by INT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_notifications_severity (severity),
  INDEX idx_notifications_created (created_at),
  CONSTRAINT fk_notifications_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6.2 Notification Recipients Table
-- (Restricted delete: preserves notification delivery and read-receipt audit history)
CREATE TABLE IF NOT EXISTS notification_recipients (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  notification_id INT NOT NULL,
  user_id INT NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  read_at TIMESTAMP NULL DEFAULT NULL,
  INDEX idx_notif_recip_user (user_id, is_read),
  CONSTRAINT fk_notif_recip_notif FOREIGN KEY (notification_id) REFERENCES notifications(id) ON DELETE RESTRICT,
  CONSTRAINT fk_notif_recip_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- MODULE 7: SECURITY, AUDIT TRAIL & SYSTEM SETTINGS
-- ----------------------------------------------------------------------------

-- 7.1 Administrative Audit Logs Table (Tamper-Resistant Operational Log)
CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT DEFAULT NULL,
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(60) NOT NULL,
  entity_id VARCHAR(60) DEFAULT NULL,
  old_values JSON DEFAULT NULL,
  new_values JSON DEFAULT NULL,
  ip_address VARCHAR(45) DEFAULT NULL,
  user_agent VARCHAR(255) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audit_user (user_id),
  INDEX idx_audit_action (action),
  INDEX idx_audit_created (created_at),
  INDEX idx_audit_entity (entity_type, entity_id),
  CONSTRAINT fk_audit_logs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7.2 Account Status History Table (Preserved Audit History: ON DELETE RESTRICT)
CREATE TABLE IF NOT EXISTS account_status_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  previous_status VARCHAR(40) DEFAULT NULL,
  new_status VARCHAR(40) NOT NULL,
  changed_by INT NOT NULL,
  reason VARCHAR(255) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_account_status_user (user_id),
  CONSTRAINT fk_account_status_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_account_status_changer FOREIGN KEY (changed_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7.3 System Settings Table
CREATE TABLE IF NOT EXISTS system_settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(100) NOT NULL UNIQUE,
  category ENUM('eoc', 'weather', 'evacuation', 'dispatch', 'system') NOT NULL DEFAULT 'system',
  setting_value TEXT DEFAULT NULL,
  description VARCHAR(255) DEFAULT NULL,
  is_protected TINYINT(1) NOT NULL DEFAULT 1,
  updated_by INT DEFAULT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_settings_key (setting_key),
  INDEX idx_settings_category (category),
  CONSTRAINT fk_settings_updater FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- INITIAL REFERENCE DATA ONLY (STRICT FRESH OPERATIONAL DATABASE)
-- (Zero fake users, zero fake reports, zero fake emergency numbers)
-- ----------------------------------------------------------------------------

-- Seed Exactly 3 Official Roles
INSERT INTO roles (id, name, description) VALUES
  (1, 'Administrator', 'Full emergency operations command, user governance, and disaster dispatch oversight'),
  (2, 'Responder', 'Field responder unit handling active incident verification and rescue missions'),
  (3, 'Resident', 'Community member reporting incidents, requesting rescue, and monitoring alerts')
ON DUPLICATE KEY UPDATE description = VALUES(description);

-- Seed Standard Incident Categories
INSERT INTO incident_categories (name, description, default_severity) VALUES
  ('Flooding / Rising Water', 'Creek overflow, street inundation, and rising lake water', 'High'),
  ('Fallen Tree / Road Obstruction', 'Blocked lanes, fallen branches, and unpassable thoroughfares', 'Medium'),
  ('Downed Electrical Cable', 'Exposed high-voltage electrical wires and snapped utility poles', 'Critical'),
  ('Structural / Wall Collapse', 'Compromised residential walls, collapsed roofs, or retaining wall failures', 'High'),
  ('Fire Outbreak', 'Active structural or electrical fire requiring immediate suppression', 'Critical'),
  ('Drainage Clogged / Overflow', 'Severe culvert clogging and localized street ponding', 'Low'),
  ('Other Disaster Hazard', 'Miscellaneous hazards requiring inspection', 'Medium')
ON DUPLICATE KEY UPDATE description = VALUES(description);

-- Seed Initial System Setting Keys (Values unconfigured pending official LGU entry)
INSERT INTO system_settings (setting_key, category, setting_value, description, is_protected) VALUES
  ('eoc_hotline_primary', 'eoc', NULL, 'Barangay Bayanan 24/7 Disaster Operations Center Hotline (Pending Official Verification)', 1),
  ('eoc_hotline_mobile', 'eoc', NULL, 'EOC Emergency Mobile Dispatch Line (Pending Official Verification)', 1),
  ('cdrmo_hotline', 'eoc', NULL, 'Muntinlupa City Disaster Risk Reduction & Management Office Hotline (Pending Official Verification)', 1),
  ('weather_refresh_minutes', 'weather', '15', 'Interval in minutes for automatic Open-Meteo weather fetch', 1),
  ('auto_triage_enabled', 'dispatch', 'true', 'Automated severity classification based on vulnerability metrics', 1)
ON DUPLICATE KEY UPDATE description = VALUES(description);
