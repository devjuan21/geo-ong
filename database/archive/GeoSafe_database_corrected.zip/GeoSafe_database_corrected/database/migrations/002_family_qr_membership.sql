-- ============================================================================
-- Migration 002: QR-Based Family Safety Tracker Membership & Fixed Bayanan Address
-- Database: geosafe_db
-- Description:
--   1. Creates family management tables with zero fake data.
--   2. Enforces fixed location coverage for Barangay Bayanan, Muntinlupa City.
--   3. Stores house_number and street separately (no ZIP, no non-Bayanan entry).
--   4. Strictly enforces one active family membership per user.
--   5. Enforces explicit revocable location consent (default 0).
--   6. Audit-safe foreign key deletion behavior (ON DELETE RESTRICT on users & members).
--   7. Neutral initial safety status ('no_response' default, never defaulted to 'safe').
-- Target Server: MySQL 8.0+ / 8.4 LTS
-- ============================================================================

USE geosafe_db;

-- 1. Family Groups (Fixed Barangay Bayanan, Muntinlupa City)
CREATE TABLE IF NOT EXISTS family_groups (
  id INT AUTO_INCREMENT PRIMARY KEY,
  family_name VARCHAR(120) NOT NULL,
  name VARCHAR(120) GENERATED ALWAYS AS (family_name) VIRTUAL,
  created_by INT NOT NULL,
  house_number VARCHAR(50) NOT NULL,
  street VARCHAR(150) NOT NULL,
  barangay VARCHAR(80) NOT NULL DEFAULT 'Bayanan',
  city VARCHAR(80) NOT NULL DEFAULT 'Muntinlupa City',
  province VARCHAR(80) NOT NULL DEFAULT 'Metro Manila',
  region VARCHAR(80) NOT NULL DEFAULT 'National Capital Region',
  country VARCHAR(80) NOT NULL DEFAULT 'Philippines',
  subdivision_purok VARCHAR(100) DEFAULT NULL,
  status ENUM('active', 'archived') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_family_groups_creator (created_by),
  INDEX idx_family_groups_status (status),
  INDEX idx_family_groups_location (barangay, city),
  CONSTRAINT chk_family_address_complete CHECK (
    house_number IS NOT NULL AND street IS NOT NULL
    AND CHAR_LENGTH(TRIM(house_number)) > 0
    AND CHAR_LENGTH(TRIM(street)) > 0
  ),
  CONSTRAINT chk_family_fixed_location CHECK (barangay = 'Bayanan' AND city = 'Muntinlupa City'),
  CONSTRAINT fk_family_groups_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Ensure fixed location coverage on existing family_groups if table was previously created
SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'family_groups' AND COLUMN_NAME = 'country');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE family_groups ADD COLUMN country VARCHAR(80) NOT NULL DEFAULT "Philippines" AFTER region', 
  'SELECT "Column family_groups.country already exists" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Non-destructive normalization of PRE-EXISTING rows:
--   * Only NULL / blank location values are filled with the fixed constants.
--   * Any existing non-blank value (including house_number, street) is NEVER modified.
--   * Rows holding a non-Bayanan / non-Muntinlupa value are left untouched and
--     reported by the diagnostic query below for manual review.
UPDATE family_groups SET barangay = 'Bayanan'                WHERE barangay IS NULL OR TRIM(barangay) = '';
UPDATE family_groups SET city = 'Muntinlupa City'           WHERE city IS NULL OR TRIM(city) = '';
UPDATE family_groups SET province = 'Metro Manila'          WHERE province IS NULL OR TRIM(province) = '';
UPDATE family_groups SET region = 'National Capital Region' WHERE region IS NULL OR TRIM(region) = '';

-- Province is retained ONLY for backward compatibility; residents never supply it.
-- subdivision_purok is retained as a legacy, optional, never-required column.
ALTER TABLE family_groups
  MODIFY COLUMN barangay VARCHAR(80) NOT NULL DEFAULT 'Bayanan',
  MODIFY COLUMN city VARCHAR(80) NOT NULL DEFAULT 'Muntinlupa City',
  MODIFY COLUMN province VARCHAR(80) NOT NULL DEFAULT 'Metro Manila',
  MODIFY COLUMN region VARCHAR(80) NOT NULL DEFAULT 'National Capital Region';

-- Diagnostic (read-only): existing rows whose stored location differs from the fixed coverage
SELECT id, family_name, house_number, street, barangay, city,
       'REVIEW: stored location differs from fixed Bayanan coverage (left unchanged)' AS note
FROM family_groups
WHERE barangay <> 'Bayanan' OR city <> 'Muntinlupa City';

-- ----------------------------------------------------------------------------
-- Database-level protection: fixed location + address validation triggers
-- ----------------------------------------------------------------------------
-- INSERT: location is always system-assigned. If an address is supplied, BOTH
-- house_number and street must be non-blank (whitespace-only is rejected) and are trimmed.
DROP TRIGGER IF EXISTS trg_family_groups_fixed_location_insert;
DELIMITER $$
CREATE TRIGGER trg_family_groups_fixed_location_insert
BEFORE INSERT ON family_groups
FOR EACH ROW
BEGIN
  SET NEW.barangay = 'Bayanan';
  SET NEW.city = 'Muntinlupa City';
  SET NEW.province = 'Metro Manila';
  SET NEW.region = 'National Capital Region';
  SET NEW.country = 'Philippines';

  -- Every NEW family group must have both resident-entered address fields.
  -- Existing incomplete rows are not rewritten by this INSERT trigger; they
  -- remain visible to the read-only verification script for manual correction.
  IF NEW.house_number IS NULL OR NEW.street IS NULL
     OR CHAR_LENGTH(TRIM(NEW.house_number)) = 0
     OR CHAR_LENGTH(TRIM(NEW.street)) = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A family address requires both a non-blank house_number and street';
  END IF;
  SET NEW.house_number = TRIM(NEW.house_number);
  SET NEW.street = TRIM(NEW.street);
END$$
DELIMITER ;

-- UPDATE: untouched legacy rows are preserved. Fixed values are re-imposed ONLY when a
-- statement attempts to change a location column; address columns are validated ONLY
-- when house_number/street are being changed.
DROP TRIGGER IF EXISTS trg_family_groups_fixed_location_update;
DELIMITER $$
CREATE TRIGGER trg_family_groups_fixed_location_update
BEFORE UPDATE ON family_groups
FOR EACH ROW
BEGIN
  IF NOT (NEW.barangay <=> OLD.barangay) OR NOT (NEW.city <=> OLD.city)
     OR NOT (NEW.province <=> OLD.province) OR NOT (NEW.region <=> OLD.region)
     OR NOT (NEW.country <=> OLD.country) THEN
    SET NEW.barangay = 'Bayanan';
    SET NEW.city = 'Muntinlupa City';
    SET NEW.province = 'Metro Manila';
    SET NEW.region = 'National Capital Region';
    SET NEW.country = 'Philippines';
  END IF;

  IF NOT (NEW.house_number <=> OLD.house_number) OR NOT (NEW.street <=> OLD.street) THEN
    IF NEW.house_number IS NULL OR NEW.street IS NULL
       OR CHAR_LENGTH(TRIM(NEW.house_number)) = 0
       OR CHAR_LENGTH(TRIM(NEW.street)) = 0 THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Family address requires non-blank house_number and street';
    END IF;
    SET NEW.house_number = TRIM(NEW.house_number);
    SET NEW.street = TRIM(NEW.street);
  END IF;
END$$
DELIMITER ;

-- 2. Family Members (Authoritative Family Relationship: Strictly One Active Family per User)
CREATE TABLE IF NOT EXISTS family_members (
  id INT AUTO_INCREMENT PRIMARY KEY,
  family_id INT NOT NULL,
  user_id INT NOT NULL,
  relationship VARCHAR(60) NOT NULL DEFAULT 'Member',
  membership_role ENUM('manager', 'member') NOT NULL DEFAULT 'member',
  membership_status ENUM('active', 'inactive', 'removed') NOT NULL DEFAULT 'active',
  joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  active_user_id INT GENERATED ALWAYS AS (CASE WHEN membership_status = 'active' THEN user_id ELSE NULL END) STORED,
  UNIQUE KEY uq_active_family_user (active_user_id),
  UNIQUE KEY uq_family_user_member (family_id, user_id),
  INDEX idx_family_members_user (user_id),
  INDEX idx_family_members_status (membership_status),
  CONSTRAINT fk_family_members_family FOREIGN KEY (family_id) REFERENCES family_groups(id) ON DELETE RESTRICT,
  CONSTRAINT fk_family_members_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Family Invitations (Secure SHA-256 Hashed Tokens - Zero Raw Secrets)
CREATE TABLE IF NOT EXISTS family_invitations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  family_id INT NOT NULL,
  token_hash VARCHAR(64) NOT NULL UNIQUE,
  created_by INT NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  revoked_at TIMESTAMP NULL DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_family_inv_hash (token_hash),
  INDEX idx_family_inv_family (family_id),
  INDEX idx_family_inv_expires (expires_at),
  CONSTRAINT chk_family_inv_token_sha256 CHECK (
    CHAR_LENGTH(token_hash) = 64 AND token_hash REGEXP '^[0-9a-fA-F]{64}$'
  ),
  CONSTRAINT fk_family_inv_family FOREIGN KEY (family_id) REFERENCES family_groups(id) ON DELETE RESTRICT,
  CONSTRAINT fk_family_inv_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Family Join Requests (Manager Review Workflow)
CREATE TABLE IF NOT EXISTS family_join_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  family_id INT NOT NULL,
  user_id INT NOT NULL,
  invitation_id INT NOT NULL,
  relationship VARCHAR(60) NOT NULL DEFAULT 'Member',
  request_status ENUM('pending', 'approved', 'rejected', 'cancelled') NOT NULL DEFAULT 'pending',
  requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  reviewed_by INT NULL DEFAULT NULL,
  reviewed_at TIMESTAMP NULL DEFAULT NULL,
  INDEX idx_join_req_family (family_id),
  INDEX idx_join_req_user (user_id),
  INDEX idx_join_req_status (request_status),
  CONSTRAINT fk_join_req_family FOREIGN KEY (family_id) REFERENCES family_groups(id) ON DELETE RESTRICT,
  CONSTRAINT fk_join_req_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_join_req_invitation FOREIGN KEY (invitation_id) REFERENCES family_invitations(id) ON DELETE RESTRICT,
  CONSTRAINT fk_join_req_reviewer FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Ensure relationship column exists on family_join_requests if table was created earlier
SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'family_join_requests' AND COLUMN_NAME = 'relationship');
SET @stmt := IF(@col_exists = 0,
  'ALTER TABLE family_join_requests ADD COLUMN relationship VARCHAR(60) NOT NULL DEFAULT "Member" AFTER invitation_id',
  'SELECT "Column family_join_requests.relationship already exists" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 5. Location Sharing Consents (Explicit, Device-Consented, Revocable Anytime)
CREATE TABLE IF NOT EXISTS family_location_sharing_consents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  family_member_id INT NOT NULL UNIQUE,
  sharing_enabled TINYINT(1) NOT NULL DEFAULT 0,
  consented_at TIMESTAMP NULL DEFAULT NULL,
  revoked_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_fam_consent_member (family_member_id),
  CONSTRAINT chk_family_consent_timestamp CHECK (
    sharing_enabled = 0 OR consented_at IS NOT NULL
  ),
  CONSTRAINT fk_fam_consent_member FOREIGN KEY (family_member_id) REFERENCES family_members(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Family Location Updates (Preserve History: ON DELETE RESTRICT on member)
CREATE TABLE IF NOT EXISTS family_location_updates (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  family_member_id INT NOT NULL,
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  battery_level TINYINT UNSIGNED DEFAULT NULL,
  safety_status ENUM('safe', 'need_help', 'injured', 'no_response') NOT NULL DEFAULT 'no_response',
  recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_fam_loc_member_time (family_member_id, recorded_at),
  CONSTRAINT fk_fam_loc_member FOREIGN KEY (family_member_id) REFERENCES family_members(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 7. Idempotent Schema & Foreign-Key Hardening for Pre-Existing Family Tables
--    - Preserves all membership, invitation, join-request, and consent history
--    - Replaces any legacy ON DELETE CASCADE on family history tables with ON DELETE RESTRICT
--    - Ensures single-active-membership generated column and unique indexes exist
-- ----------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_geosafe_harden_family_membership;
DELIMITER $$
CREATE PROCEDURE sp_geosafe_harden_family_membership()
BEGIN
  DECLARE v_dup_active INT DEFAULT 0;

  -- Pre-flight check: detect if any user currently holds > 1 active membership
  SELECT COUNT(*) INTO v_dup_active
  FROM (
    SELECT user_id
    FROM family_members
    WHERE membership_status = 'active'
    GROUP BY user_id
    HAVING COUNT(*) > 1
  ) dup;

  IF v_dup_active > 0 THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Family membership migration halted: user(s) with multiple active memberships detected in family_members. Resolve before adding uq_active_family_user.';
  END IF;

  -- Ensure active_user_id generated column exists on family_members
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'family_members' AND COLUMN_NAME = 'active_user_id'
  ) THEN
    ALTER TABLE family_members
      ADD COLUMN active_user_id INT GENERATED ALWAYS AS (CASE WHEN membership_status = 'active' THEN user_id ELSE NULL END) STORED;
  END IF;

  -- Ensure uq_active_family_user unique key exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'family_members' AND INDEX_NAME = 'uq_active_family_user'
  ) THEN
    ALTER TABLE family_members ADD UNIQUE KEY uq_active_family_user (active_user_id);
  END IF;

  -- Ensure uq_family_user_member unique key exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'family_members' AND INDEX_NAME = 'uq_family_user_member'
  ) THEN
    ALTER TABLE family_members ADD UNIQUE KEY uq_family_user_member (family_id, user_id);
  END IF;

  -- Upgrade fk_family_members_family from CASCADE to RESTRICT to preserve membership history
  IF EXISTS (
    SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS
    WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_family_members_family' AND DELETE_RULE <> 'RESTRICT'
  ) THEN
    ALTER TABLE family_members DROP FOREIGN KEY fk_family_members_family;
    ALTER TABLE family_members
      ADD CONSTRAINT fk_family_members_family FOREIGN KEY (family_id) REFERENCES family_groups(id) ON DELETE RESTRICT;
  END IF;

  -- Upgrade fk_family_inv_family from CASCADE to RESTRICT to preserve invitation history
  IF EXISTS (
    SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS
    WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_family_inv_family' AND DELETE_RULE <> 'RESTRICT'
  ) THEN
    ALTER TABLE family_invitations DROP FOREIGN KEY fk_family_inv_family;
    ALTER TABLE family_invitations
      ADD CONSTRAINT fk_family_inv_family FOREIGN KEY (family_id) REFERENCES family_groups(id) ON DELETE RESTRICT;
  END IF;

  -- Upgrade fk_join_req_family from CASCADE to RESTRICT to preserve join request history
  IF EXISTS (
    SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS
    WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_join_req_family' AND DELETE_RULE <> 'RESTRICT'
  ) THEN
    ALTER TABLE family_join_requests DROP FOREIGN KEY fk_join_req_family;
    ALTER TABLE family_join_requests
      ADD CONSTRAINT fk_join_req_family FOREIGN KEY (family_id) REFERENCES family_groups(id) ON DELETE RESTRICT;
  END IF;

  -- Upgrade fk_fam_consent_member from CASCADE to RESTRICT to preserve consent audit history
  IF EXISTS (
    SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS
    WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_fam_consent_member' AND DELETE_RULE <> 'RESTRICT'
  ) THEN
    ALTER TABLE family_location_sharing_consents DROP FOREIGN KEY fk_fam_consent_member;
    ALTER TABLE family_location_sharing_consents
      ADD CONSTRAINT fk_fam_consent_member FOREIGN KEY (family_member_id) REFERENCES family_members(id) ON DELETE RESTRICT;
  END IF;

  -- Upgrade fk_join_req_reviewer from SET NULL to RESTRICT so reviewer attribution is preserved
  IF EXISTS (
    SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS
    WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_join_req_reviewer' AND DELETE_RULE <> 'RESTRICT'
  ) THEN
    ALTER TABLE family_join_requests DROP FOREIGN KEY fk_join_req_reviewer;
    ALTER TABLE family_join_requests
      ADD CONSTRAINT fk_join_req_reviewer FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE RESTRICT;
  END IF;
END$$
DELIMITER ;

CALL sp_geosafe_harden_family_membership();
DROP PROCEDURE IF EXISTS sp_geosafe_harden_family_membership;

-- ----------------------------------------------------------------------------
-- 8. Database-Level Invitation, Consent & Location-Sharing Protection Triggers
-- ----------------------------------------------------------------------------

-- 8.1 Enforce SHA-256 hashed invitation tokens (never store raw tokens) and future expiration
DROP TRIGGER IF EXISTS trg_family_invitations_validate_insert;
DELIMITER $$
CREATE TRIGGER trg_family_invitations_validate_insert
BEFORE INSERT ON family_invitations
FOR EACH ROW
BEGIN
  IF NEW.token_hash IS NULL OR CHAR_LENGTH(NEW.token_hash) <> 64 OR NEW.token_hash NOT REGEXP '^[0-9a-fA-F]{64}$' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid invitation token_hash: must be a 64-character hexadecimal SHA-256 hash';
  END IF;

  IF NEW.expires_at <= COALESCE(NEW.created_at, CURRENT_TIMESTAMP) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid invitation expires_at: expiration timestamp must be in the future';
  END IF;
END$$
DELIMITER ;

-- 8.2 Enforce explicit consent rules on family_location_sharing_consents
DROP TRIGGER IF EXISTS trg_family_consent_validate_insert;
DELIMITER $$
CREATE TRIGGER trg_family_consent_validate_insert
BEFORE INSERT ON family_location_sharing_consents
FOR EACH ROW
BEGIN
  DECLARE v_member_status VARCHAR(20);

  SELECT membership_status INTO v_member_status
  FROM family_members
  WHERE id = NEW.family_member_id
  LIMIT 1;

  IF NEW.sharing_enabled = 1 THEN
    IF v_member_status IS NULL OR v_member_status <> 'active' THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Location sharing cannot be enabled for an inactive or removed family member';
    END IF;
    IF NEW.consented_at IS NULL THEN
      SET NEW.consented_at = CURRENT_TIMESTAMP;
    END IF;
    SET NEW.revoked_at = NULL;
  ELSE
    SET NEW.sharing_enabled = 0;
  END IF;
END$$
DELIMITER ;

DROP TRIGGER IF EXISTS trg_family_consent_validate_update;
DELIMITER $$
CREATE TRIGGER trg_family_consent_validate_update
BEFORE UPDATE ON family_location_sharing_consents
FOR EACH ROW
BEGIN
  DECLARE v_member_status VARCHAR(20);

  SELECT membership_status INTO v_member_status
  FROM family_members
  WHERE id = NEW.family_member_id
  LIMIT 1;

  IF NEW.sharing_enabled = 1 THEN
    IF v_member_status IS NULL OR v_member_status <> 'active' THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Location sharing cannot be enabled for an inactive or removed family member';
    END IF;
    IF NEW.consented_at IS NULL THEN
      SET NEW.consented_at = CURRENT_TIMESTAMP;
    END IF;
    SET NEW.revoked_at = NULL;
  ELSEIF NEW.sharing_enabled = 0 AND OLD.sharing_enabled = 1 THEN
    IF NEW.revoked_at IS NULL THEN
      SET NEW.revoked_at = CURRENT_TIMESTAMP;
    END IF;
  END IF;
END$$
DELIMITER ;

-- 8.3 Require active membership and explicit enabled consent before recording location updates
--     and ensure missing safety_status is never defaulted to 'safe'
DROP TRIGGER IF EXISTS trg_family_location_updates_require_consent;
DELIMITER $$
CREATE TRIGGER trg_family_location_updates_require_consent
BEFORE INSERT ON family_location_updates
FOR EACH ROW
BEGIN
  DECLARE v_member_status VARCHAR(20);
  DECLARE v_sharing_enabled TINYINT(1);

  SELECT fm.membership_status, COALESCE(flc.sharing_enabled, 0)
    INTO v_member_status, v_sharing_enabled
  FROM family_members fm
  LEFT JOIN family_location_sharing_consents flc ON flc.family_member_id = fm.id
  WHERE fm.id = NEW.family_member_id
  LIMIT 1;

  IF v_member_status IS NULL OR v_member_status <> 'active' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot record location update: family member is not active';
  END IF;

  IF v_sharing_enabled <> 1 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot record location update: explicit location-sharing consent is disabled';
  END IF;

  IF NEW.safety_status IS NULL THEN
    SET NEW.safety_status = 'no_response';
  END IF;
END$$
DELIMITER ;
