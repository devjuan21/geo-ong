-- ============================================================================
-- GeoSafe Migration 003: Core User Role Synchronization & Schema Alignment
-- Target Database: geosafe_db
-- Description:
--   1. Authoritative Role Relationship: Enforces roles.id and users.role_id as
--      authoritative, while synchronizing users.role ENUM for backend compatibility.
--   2. Enforces bidirectional triggers to prevent role_id and role mismatches.
--   3. Sets neutral initial safety_status ('no_response', never defaulted to 'safe').
--   4. Synchronizes users.family_group_id with authoritative family_members table.
--   5. Adds password reset token hash and expiration fields.
-- Prerequisites: geosafe_db_schema.sql and Migration 002 completed.
-- Execution Safety: Strict MySQL 8.4 compatibility, idempotent, zero fake data.
-- ============================================================================

USE geosafe_db;

-- ----------------------------------------------------------------------------
-- 1. Ensure `roles` Contains Strictly the Canonical 3 Roles
-- ----------------------------------------------------------------------------
INSERT INTO roles (id, name, description) VALUES
  (1, 'Administrator', 'Full emergency operations command, user governance, and disaster dispatch oversight'),
  (2, 'Responder', 'Field responder unit handling active incident verification and rescue missions'),
  (3, 'Resident', 'Community member reporting incidents, requesting rescue, and monitoring alerts')
ON DUPLICATE KEY UPDATE description = VALUES(description);

-- ----------------------------------------------------------------------------
-- 2. Add / Synchronize `role` Column on `users` Table
--    Note: `users.role_id` referencing `roles.id` is the single authoritative
--    role relationship. `users.role` uses DEFAULT NULL at the column level so
--    omitting `role` on INSERT never supplies a premature 'resident' default
--    before `trg_users_sync_role_insert` derives `NEW.role` from `NEW.role_id`.
-- ----------------------------------------------------------------------------
SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'users' AND COLUMN_NAME = 'role');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE users ADD COLUMN role ENUM(\'admin\', \'responder\', \'resident\') DEFAULT NULL AFTER role_id, ADD INDEX idx_users_role (role)', 
  'ALTER TABLE users MODIFY COLUMN role ENUM(\'admin\', \'responder\', \'resident\') DEFAULT NULL');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Sync users.role from authoritative roles table
UPDATE users u
JOIN roles r ON u.role_id = r.id
SET u.role = CASE
  WHEN r.name = 'Administrator' THEN 'admin'
  WHEN r.name = 'Responder' THEN 'responder'
  ELSE 'resident'
END;

-- Sync users.role_id from users.role where role_id was not set
UPDATE users u
SET u.role_id = CASE
  WHEN u.role = 'admin' THEN 1
  WHEN u.role = 'responder' THEN 2
  ELSE 3
END
WHERE u.role_id NOT IN (1, 2, 3);

-- Add contact_number to users
SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'users' AND COLUMN_NAME = 'contact_number');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE users ADD COLUMN contact_number VARCHAR(35) DEFAULT NULL AFTER email', 
  'SELECT "Column users.contact_number already exists" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add address to users (no fake default address)
SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'users' AND COLUMN_NAME = 'address');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE users ADD COLUMN address VARCHAR(255) DEFAULT NULL AFTER contact_number', 
  'SELECT "Column users.address already exists" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add safety_status with neutral 'no_response' default (never default to 'safe')
SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'users' AND COLUMN_NAME = 'safety_status');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE users ADD COLUMN safety_status ENUM(\'safe\', \'need_help\', \'injured\', \'no_response\') NOT NULL DEFAULT \'no_response\' AFTER address, ADD INDEX idx_users_safety_status (safety_status)', 
  'ALTER TABLE users MODIFY COLUMN safety_status ENUM(\'safe\', \'need_help\', \'injured\', \'no_response\') NOT NULL DEFAULT \'no_response\'');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add coordinates (default NULL, never default to arbitrary coordinates)
SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'users' AND COLUMN_NAME = 'last_latitude');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE users ADD COLUMN last_latitude DECIMAL(10, 8) DEFAULT NULL AFTER safety_status, ADD COLUMN last_longitude DECIMAL(11, 8) DEFAULT NULL AFTER last_latitude', 
  'SELECT "Coordinates columns already exist on users" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add battery_level to users
SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'users' AND COLUMN_NAME = 'battery_level');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE users ADD COLUMN battery_level TINYINT UNSIGNED DEFAULT NULL AFTER last_longitude', 
  'SELECT "Column users.battery_level already exists" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add family_group_id to users as a legacy compatibility cache. family_members remains authoritative.
SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'users' AND COLUMN_NAME = 'family_group_id');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE users ADD COLUMN family_group_id INT DEFAULT NULL AFTER battery_level, ADD INDEX idx_users_family_group (family_group_id), ADD CONSTRAINT fk_users_family_group FOREIGN KEY (family_group_id) REFERENCES family_groups(id) ON DELETE RESTRICT', 
  'SELECT "Column users.family_group_id already exists" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Ensure the legacy cache has a real FK even when the column already existed
-- in the base schema. If orphan values exist, this ALTER fails safely and must
-- be resolved manually; no rows are deleted or rewritten here.
SET @fk_exists := (SELECT COUNT(*) FROM information_schema.REFERENTIAL_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'users'
    AND CONSTRAINT_NAME = 'fk_users_family_group');
SET @stmt := IF(@fk_exists = 0,
  'ALTER TABLE users ADD CONSTRAINT fk_users_family_group FOREIGN KEY (family_group_id) REFERENCES family_groups(id) ON DELETE RESTRICT ON UPDATE CASCADE',
  'SELECT "Foreign key fk_users_family_group already exists" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Sync users.family_group_id with authoritative active family_members (sets NULL when no active membership)
UPDATE users u
LEFT JOIN (
  SELECT fm.user_id, fm.family_id
  FROM family_members fm
  JOIN family_groups fg ON fg.id = fm.family_id
  WHERE fm.membership_status = 'active' AND fg.status = 'active'
) auth_fm ON u.id = auth_fm.user_id
SET u.family_group_id = auth_fm.family_id;

-- Add secure password reset tokens (SHA-256 hash) to users
SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'users' AND COLUMN_NAME = 'reset_token_hash');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE users ADD COLUMN reset_token_hash VARCHAR(64) DEFAULT NULL AFTER password_hash, ADD COLUMN reset_token_expires_at TIMESTAMP NULL DEFAULT NULL AFTER reset_token_hash, ADD INDEX idx_users_reset_token (reset_token_hash)', 
  'SELECT "Password reset columns already exist on users" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ----------------------------------------------------------------------------
-- 3. Role synchronization and legacy family cache maintenance.
--    users.role_id is authoritative. family_members is the authoritative family relationship;
--    users.family_group_id is a deprecated compatibility cache and MUST NOT drive authorization.
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_users_sync_role_insert;
DELIMITER $$
CREATE TRIGGER trg_users_sync_role_insert
BEFORE INSERT ON users
FOR EACH ROW
BEGIN
  -- 1. Role synchronization (role_id is authoritative)
  IF NEW.role_id IS NOT NULL AND NEW.role IS NOT NULL THEN
    IF (NEW.role_id = 1 AND NEW.role <> 'admin') OR
       (NEW.role_id = 2 AND NEW.role <> 'responder') OR
       (NEW.role_id = 3 AND NEW.role <> 'resident') OR
       (NEW.role_id NOT IN (1, 2, 3)) THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Role mismatch or invalid role: role_id and role must match canonical roles (1=admin, 2=responder, 3=resident)';
    END IF;
  ELSEIF NEW.role_id IS NOT NULL THEN
    IF NEW.role_id = 1 THEN
      SET NEW.role = 'admin';
    ELSEIF NEW.role_id = 2 THEN
      SET NEW.role = 'responder';
    ELSEIF NEW.role_id = 3 THEN
      SET NEW.role = 'resident';
    ELSE
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid role_id: Must be 1 (Administrator), 2 (Responder), or 3 (Resident)';
    END IF;
  ELSEIF NEW.role IS NOT NULL THEN
    IF NEW.role = 'admin' THEN
      SET NEW.role_id = 1;
    ELSEIF NEW.role = 'responder' THEN
      SET NEW.role_id = 2;
    ELSEIF NEW.role = 'resident' THEN
      SET NEW.role_id = 3;
    ELSE
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid role: Must be admin, responder, or resident';
    END IF;
  ELSE
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Role assignment required: supply authoritative role_id (1=Administrator, 2=Responder, 3=Resident)';
  END IF;

  -- 2. Prevent unverified family_group_id assignment on user creation
  --    (Membership must be established via authoritative family_members)
  IF NEW.family_group_id IS NOT NULL THEN
    SET NEW.family_group_id = NULL;
  END IF;
END$$
DELIMITER ;

DROP TRIGGER IF EXISTS trg_users_sync_role_update;
DELIMITER $$
CREATE TRIGGER trg_users_sync_role_update
BEFORE UPDATE ON users
FOR EACH ROW
BEGIN
  -- 1. Role synchronization on UPDATE
  IF NOT (NEW.role_id <=> OLD.role_id) AND NOT (NEW.role <=> OLD.role) THEN
    IF (NEW.role_id = 1 AND NEW.role <> 'admin') OR
       (NEW.role_id = 2 AND NEW.role <> 'responder') OR
       (NEW.role_id = 3 AND NEW.role <> 'resident') OR
       (NEW.role_id NOT IN (1, 2, 3)) THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Role mismatch on update: role_id and role must match canonical roles (1=admin, 2=responder, 3=resident)';
    END IF;
  ELSEIF NOT (NEW.role_id <=> OLD.role_id) THEN
    IF NEW.role_id = 1 THEN
      SET NEW.role = 'admin';
    ELSEIF NEW.role_id = 2 THEN
      SET NEW.role = 'responder';
    ELSEIF NEW.role_id = 3 THEN
      SET NEW.role = 'resident';
    ELSE
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid role_id: Must be 1 (Administrator), 2 (Responder), or 3 (Resident)';
    END IF;
  ELSEIF NOT (NEW.role <=> OLD.role) THEN
    IF NEW.role = 'admin' THEN
      SET NEW.role_id = 1;
    ELSEIF NEW.role = 'responder' THEN
      SET NEW.role_id = 2;
    ELSEIF NEW.role = 'resident' THEN
      SET NEW.role_id = 3;
    ELSE
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid role: Must be admin, responder, or resident';
    END IF;
  END IF;

  -- family_group_id is a deprecated compatibility cache, not an authorization source.
  -- All authorization and membership decisions MUST query family_members.
END$$
DELIMITER ;

-- ----------------------------------------------------------------------------
-- 4. Legacy family cache maintenance and consent revocation.
--    No user-defined session variable is used as a security boundary.
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_family_members_sync_user_insert;
DELIMITER $$
CREATE TRIGGER trg_family_members_sync_user_insert
AFTER INSERT ON family_members
FOR EACH ROW
BEGIN
  IF NEW.membership_status = 'active' THEN
    UPDATE users SET family_group_id = NEW.family_id WHERE id = NEW.user_id;
  END IF;
END$$
DELIMITER ;

DROP TRIGGER IF EXISTS trg_family_members_sync_user_update;
DELIMITER $$
CREATE TRIGGER trg_family_members_sync_user_update
AFTER UPDATE ON family_members
FOR EACH ROW
BEGIN
  IF NEW.membership_status = 'active' THEN
    UPDATE users SET family_group_id = NEW.family_id WHERE id = NEW.user_id;
  ELSEIF NEW.membership_status <> 'active' AND OLD.membership_status = 'active' THEN
    UPDATE users SET family_group_id = NULL WHERE id = NEW.user_id;
    -- Automatically revoke location-sharing consent when member becomes inactive or removed
    UPDATE family_location_sharing_consents
    SET sharing_enabled = 0,
        revoked_at = COALESCE(revoked_at, CURRENT_TIMESTAMP)
    WHERE family_member_id = NEW.id AND sharing_enabled = 1;
  END IF;
END$$
DELIMITER ;

DROP TRIGGER IF EXISTS trg_family_members_sync_user_delete;
DELIMITER $$
CREATE TRIGGER trg_family_members_sync_user_delete
AFTER DELETE ON family_members
FOR EACH ROW
BEGIN
  IF OLD.membership_status = 'active' THEN
    UPDATE users SET family_group_id = NULL WHERE id = OLD.user_id;
  END IF;
END$$
DELIMITER ;

DROP TRIGGER IF EXISTS trg_family_groups_sync_status_update;
DELIMITER $$
CREATE TRIGGER trg_family_groups_sync_status_update
AFTER UPDATE ON family_groups
FOR EACH ROW
BEGIN
  IF NEW.status = 'archived' AND OLD.status <> 'archived' THEN
    -- Deactivate any remaining active members in the archived group
    -- (trg_family_members_sync_user_update revokes consent and clears users.family_group_id)
    UPDATE family_members
    SET membership_status = 'inactive'
    WHERE family_id = NEW.id AND membership_status = 'active';

    -- Revoke any active QR invitations for the archived family
    UPDATE family_invitations
    SET revoked_at = CURRENT_TIMESTAMP
    WHERE family_id = NEW.id AND revoked_at IS NULL;

    -- Cancel any pending join requests for the archived family
    UPDATE family_join_requests
    SET request_status = 'cancelled',
        reviewed_at = COALESCE(reviewed_at, CURRENT_TIMESTAMP)
    WHERE family_id = NEW.id AND request_status = 'pending';

    -- Ensure cached family_group_id is cleared on users whose family group was archived
    UPDATE users
    SET family_group_id = NULL
    WHERE family_group_id = NEW.id;
  END IF;
END$$
DELIMITER ;

-- ----------------------------------------------------------------------------
-- 5. Extend `family_groups` with Name Alias Column (Virtual Generated)
-- ----------------------------------------------------------------------------
SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'family_groups' AND COLUMN_NAME = 'name');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE family_groups ADD COLUMN name VARCHAR(120) GENERATED ALWAYS AS (family_name) VIRTUAL', 
  'SELECT "Column family_groups.name already exists" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
