-- ============================================================================
-- GeoSafe Migration 004: Canonical Incident Consolidation, Assignments & Work Notes
-- Target Database: geosafe_db
-- Description:
--   1. Establishes `reports` as the single authoritative canonical table for all
--      portals (Resident, Responder, and Administrator).
--   2. Pre-flight report: ID collisions, reference-number collisions, orphan children.
--   3. Copies every legacy `incident_reports` row into `reports`: original ID kept when
--      free, matched when identical, otherwise copied under a new ID. Each outcome is
--      recorded in `incident_migration_map`. Nothing is skipped: the procedure aborts
--      (SIGNAL) if any row cannot be mapped. No INSERT IGNORE is used.
--   4. Repoints incident_attachments, incident_status_history and
--      responder_assignment_history to `reports(id)` (remapping IDs through the map);
--      incident_assignments / incident_updates are created on `reports(id)`.
--   5. Freezes `incident_reports` as READ-ONLY (reject-writes triggers, no data sync).
--      The legacy table is NOT dropped; retire it only after verification.
--   Take a mysqldump before running. No fake or sample incidents are inserted.
-- Prerequisites: Migration 003 completed.
-- Execution Safety: Strict MySQL 8.4 compatibility, InnoDB, zero dummy records.
-- ============================================================================

USE geosafe_db;

-- ----------------------------------------------------------------------------
-- 1. Canonical `reports` Table (Single Source of Truth for Incidents)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reports (
  id INT AUTO_INCREMENT PRIMARY KEY,
  reference_number VARCHAR(40) DEFAULT NULL UNIQUE,
  user_id INT NOT NULL,
  category_id INT DEFAULT NULL,
  incident_type VARCHAR(100) NOT NULL,
  title VARCHAR(180) DEFAULT NULL,
  description TEXT NOT NULL,
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  address VARCHAR(255) DEFAULT NULL,
  severity ENUM('low', 'medium', 'high', 'critical') NOT NULL DEFAULT 'medium',
  status ENUM('pending', 'verified', 'responding', 'on_site', 'resolved', 'dismissed') NOT NULL DEFAULT 'pending',
  assigned_to INT DEFAULT NULL,
  verified_by INT DEFAULT NULL,
  verified_at TIMESTAMP NULL DEFAULT NULL,
  resolved_at TIMESTAMP NULL DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_reports_ref (reference_number),
  INDEX idx_reports_user (user_id),
  INDEX idx_reports_category (category_id),
  INDEX idx_reports_status (status),
  INDEX idx_reports_severity (severity),
  INDEX idx_reports_assigned_to (assigned_to),
  INDEX idx_reports_created (created_at),
  INDEX idx_reports_coords (latitude, longitude),
  CONSTRAINT fk_reports_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_reports_category FOREIGN KEY (category_id) REFERENCES incident_categories(id) ON DELETE RESTRICT,
  CONSTRAINT fk_reports_assigned FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_reports_verifier FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Extend existing reports table if columns do not exist yet
SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'reports' AND COLUMN_NAME = 'reference_number');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE reports ADD COLUMN reference_number VARCHAR(40) DEFAULT NULL UNIQUE AFTER id, ADD INDEX idx_reports_ref (reference_number)', 
  'SELECT "Column reports.reference_number already exists" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'reports' AND COLUMN_NAME = 'category_id');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE reports ADD COLUMN category_id INT DEFAULT NULL AFTER user_id, ADD CONSTRAINT fk_reports_category FOREIGN KEY (category_id) REFERENCES incident_categories(id) ON DELETE RESTRICT, ADD INDEX idx_reports_category (category_id)', 
  'SELECT "Column reports.category_id already exists" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'reports' AND COLUMN_NAME = 'title');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE reports ADD COLUMN title VARCHAR(180) DEFAULT NULL AFTER incident_type', 
  'SELECT "Column reports.title already exists" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'reports' AND COLUMN_NAME = 'address');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE reports ADD COLUMN address VARCHAR(255) DEFAULT NULL AFTER longitude', 
  'SELECT "Column reports.address already exists" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'reports' AND COLUMN_NAME = 'verified_by');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE reports ADD COLUMN verified_by INT DEFAULT NULL AFTER assigned_to, ADD COLUMN verified_at TIMESTAMP NULL DEFAULT NULL AFTER verified_by, ADD COLUMN resolved_at TIMESTAMP NULL DEFAULT NULL AFTER verified_at, ADD CONSTRAINT fk_reports_verifier FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE RESTRICT', 
  'SELECT "Verification columns already exist on reports" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;


-- ----------------------------------------------------------------------------
-- 2. Incident Assignments & Field Updates (reference canonical reports(id) only)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS incident_assignments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  report_id INT NOT NULL,
  responder_user_id INT NOT NULL,
  assigned_by INT NOT NULL,
  dispatch_instructions TEXT DEFAULT NULL,
  status ENUM('Assigned', 'Accepted', 'En Route', 'On Scene', 'Resolved', 'Cancelled') NOT NULL DEFAULT 'Assigned',
  priority ENUM('Critical', 'High', 'Medium', 'Low') NOT NULL DEFAULT 'Medium',
  assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  accepted_at TIMESTAMP NULL DEFAULT NULL,
  resolved_at TIMESTAMP NULL DEFAULT NULL,
  INDEX idx_inc_assign_report (report_id),
  INDEX idx_inc_assign_responder (responder_user_id),
  INDEX idx_inc_assign_status (status),
  INDEX idx_inc_assign_priority (priority),
  CONSTRAINT fk_inc_assign_report FOREIGN KEY (report_id) REFERENCES reports(id) ON DELETE RESTRICT,
  CONSTRAINT fk_inc_assign_responder FOREIGN KEY (responder_user_id) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_inc_assign_dispatcher FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS incident_updates (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  report_id INT NOT NULL,
  responder_user_id INT NOT NULL,
  status_update VARCHAR(40) NOT NULL,
  work_notes TEXT NOT NULL,
  photo_url VARCHAR(255) DEFAULT NULL,
  is_internal_only TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_inc_updates_report (report_id),
  INDEX idx_inc_updates_responder (responder_user_id),
  INDEX idx_inc_updates_privacy (is_internal_only),
  INDEX idx_inc_updates_created (created_at),
  CONSTRAINT fk_inc_updates_report FOREIGN KEY (report_id) REFERENCES reports(id) ON DELETE RESTRICT,
  CONSTRAINT fk_inc_updates_responder FOREIGN KEY (responder_user_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 3. Legacy table alignment (PRE-STEP ONLY: ensures the migration SELECT can read
--    columns on very old installs; adds nullable columns, never alters data)
-- ----------------------------------------------------------------------------
SET @legacy_exists := (SELECT COUNT(*) FROM information_schema.TABLES
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'incident_reports');

SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'incident_reports' AND COLUMN_NAME = 'assigned_to');
SET @stmt := IF(@legacy_exists = 1 AND @col_exists = 0,
  'ALTER TABLE incident_reports ADD COLUMN assigned_to INT DEFAULT NULL',
  'SELECT "legacy assigned_to present or legacy table absent" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'incident_reports' AND COLUMN_NAME = 'incident_type');
SET @stmt := IF(@legacy_exists = 1 AND @col_exists = 0,
  'ALTER TABLE incident_reports ADD COLUMN incident_type VARCHAR(100) DEFAULT NULL',
  'SELECT "legacy incident_type present or legacy table absent" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ----------------------------------------------------------------------------
-- 4. Legacy-ID Mapping Table (audit trail of exactly where every legacy incident went)
--    legacy_incident_id    : incident_reports.id
--    canonical_report_id   : reports.id that now represents that incident
--    resolution            : same_id         -> legacy ID was free; ID preserved
--                            matched_existing-> identical record already in reports
--                            reassigned_id   -> legacy ID collided with a DIFFERENT
--                                               incident; copied under a new reports.id
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS incident_migration_map (
  legacy_incident_id INT NOT NULL PRIMARY KEY,
  canonical_report_id INT NOT NULL,
  resolution ENUM('same_id', 'matched_existing', 'reassigned_id') NOT NULL,
  migrated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_incident_map_canonical (canonical_report_id),
  CONSTRAINT fk_incident_map_report FOREIGN KEY (canonical_report_id) REFERENCES reports(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 5. READ-ONLY PRE-FLIGHT REPORT (review BEFORE trusting the migration; safe to run alone)
-- ----------------------------------------------------------------------------
-- 5.1 Row counts
SELECT
  (SELECT COUNT(*) FROM incident_reports) AS legacy_incident_reports,
  (SELECT COUNT(*) FROM reports) AS canonical_reports;

-- 5.2 ID collisions between legacy and canonical, classified
SELECT ir.id AS legacy_id, ir.reference_number AS legacy_reference, r.id AS reports_id,
  CASE WHEN r.reference_number <=> ir.reference_number
      AND r.user_id <=> ir.user_id
      AND r.category_id <=> ir.category_id
      AND r.incident_type <=> COALESCE(ir.incident_type, ic.name, ir.title, 'General Incident')
      AND r.title <=> ir.title
      AND r.description <=> ir.description
      AND r.latitude <=> ir.latitude
      AND r.longitude <=> ir.longitude
      AND r.address <=> ir.address
      AND r.severity <=> LOWER(ir.severity)
      AND r.status <=> CASE ir.status
        WHEN 'Responding' THEN 'responding' WHEN 'On Scene' THEN 'on_site'
        WHEN 'Resolved' THEN 'resolved' WHEN 'Dismissed' THEN 'dismissed'
        WHEN 'Verified' THEN 'verified' ELSE 'pending' END
      AND r.assigned_to <=> ir.assigned_to
      AND r.verified_by <=> ir.verified_by
      AND r.verified_at <=> ir.verified_at
      AND r.resolved_at <=> ir.resolved_at
      AND r.created_at <=> ir.created_at
      AND r.updated_at <=> ir.updated_at
       THEN 'IDENTICAL: all incident fields match; will map to existing record'
       ELSE 'DIFFERENT INCIDENT, SAME ID: legacy copy gets a new reports.id (children repointed)'
  END AS id_conflict_resolution
FROM incident_reports ir
LEFT JOIN incident_categories ic ON ic.id = ir.category_id
JOIN reports r ON r.id = ir.id;

-- 5.3 Reference-number collisions that are NOT the same incident (these ABORT the migration)
SELECT ir.id AS legacy_id, ir.reference_number, r.id AS reports_id
FROM incident_reports ir
LEFT JOIN incident_categories ic ON ic.id = ir.category_id
JOIN reports r ON r.reference_number = ir.reference_number
WHERE NOT (r.reference_number <=> ir.reference_number
      AND r.user_id <=> ir.user_id
      AND r.category_id <=> ir.category_id
      AND r.incident_type <=> COALESCE(ir.incident_type, ic.name, ir.title, 'General Incident')
      AND r.title <=> ir.title
      AND r.description <=> ir.description
      AND r.latitude <=> ir.latitude
      AND r.longitude <=> ir.longitude
      AND r.address <=> ir.address
      AND r.severity <=> LOWER(ir.severity)
      AND r.status <=> CASE ir.status
        WHEN 'Responding' THEN 'responding' WHEN 'On Scene' THEN 'on_site'
        WHEN 'Resolved' THEN 'resolved' WHEN 'Dismissed' THEN 'dismissed'
        WHEN 'Verified' THEN 'verified' ELSE 'pending' END
      AND r.assigned_to <=> ir.assigned_to
      AND r.verified_by <=> ir.verified_by
      AND r.verified_at <=> ir.verified_at
      AND r.resolved_at <=> ir.resolved_at
      AND r.created_at <=> ir.created_at
      AND r.updated_at <=> ir.updated_at);

-- 5.4 Child rows whose incident_id has no matching legacy incident (these ABORT the migration)
SELECT 'incident_attachments' AS child_table, COUNT(*) AS orphan_rows FROM incident_attachments c
  WHERE NOT EXISTS (SELECT 1 FROM incident_reports ir WHERE ir.id = c.incident_id)
    AND NOT EXISTS (SELECT 1 FROM reports r WHERE r.id = c.incident_id)
UNION ALL
SELECT 'incident_status_history', COUNT(*) FROM incident_status_history c
  WHERE NOT EXISTS (SELECT 1 FROM incident_reports ir WHERE ir.id = c.incident_id)
    AND NOT EXISTS (SELECT 1 FROM reports r WHERE r.id = c.incident_id)
UNION ALL
SELECT 'responder_assignment_history', COUNT(*) FROM responder_assignment_history c
  WHERE c.incident_id IS NOT NULL
    AND NOT EXISTS (SELECT 1 FROM incident_reports ir WHERE ir.id = c.incident_id)
    AND NOT EXISTS (SELECT 1 FROM reports r WHERE r.id = c.incident_id);

-- ----------------------------------------------------------------------------
-- 6. Consolidation Procedure (aborts loudly; never silently skips a legacy record)
--    Uses guarded mapping inserts. DDL implicitly commits; interrupted runs require manual checkpoint review.
-- ----------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_geosafe_consolidate_incidents;
DELIMITER $$
CREATE PROCEDURE sp_geosafe_consolidate_incidents()
BEGIN
  DECLARE v_legacy_exists INT DEFAULT 0;
  DECLARE v_blockers INT DEFAULT 0;
  DECLARE v_legacy_count INT DEFAULT 0;
  DECLARE v_unmapped INT DEFAULT 0;
  DECLARE v_orphans INT DEFAULT 0;
  DECLARE v_mismatches INT DEFAULT 0;
  DECLARE v_fk VARCHAR(64);
  DECLARE v_has_fk INT DEFAULT 0;

  SELECT COUNT(*) INTO v_legacy_exists FROM information_schema.TABLES
    WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'incident_reports';

  IF v_legacy_exists > 0 THEN

    -- 6.1 Abort on reference_number collisions that are different incidents
    SELECT COUNT(*) INTO v_blockers
    FROM incident_reports ir
    LEFT JOIN incident_categories ic ON ic.id = ir.category_id
    JOIN reports r ON r.reference_number = ir.reference_number
    WHERE NOT (r.reference_number <=> ir.reference_number
      AND r.user_id <=> ir.user_id
      AND r.category_id <=> ir.category_id
      AND r.incident_type <=> COALESCE(ir.incident_type, ic.name, ir.title, 'General Incident')
      AND r.title <=> ir.title
      AND r.description <=> ir.description
      AND r.latitude <=> ir.latitude
      AND r.longitude <=> ir.longitude
      AND r.address <=> ir.address
      AND r.severity <=> LOWER(ir.severity)
      AND r.status <=> CASE ir.status
        WHEN 'Responding' THEN 'responding' WHEN 'On Scene' THEN 'on_site'
        WHEN 'Resolved' THEN 'resolved' WHEN 'Dismissed' THEN 'dismissed'
        WHEN 'Verified' THEN 'verified' ELSE 'pending' END
      AND r.assigned_to <=> ir.assigned_to
      AND r.verified_by <=> ir.verified_by
      AND r.verified_at <=> ir.verified_at
      AND r.resolved_at <=> ir.resolved_at
      AND r.created_at <=> ir.created_at
      AND r.updated_at <=> ir.updated_at);
    IF v_blockers > 0 THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
        'Incident migration aborted: reference_number collision between different incidents. Resolve manually (see pre-flight 5.3).';
    END IF;

    -- 6.2 Abort if any child row points at an incident that exists in neither table
    SELECT COUNT(*) INTO v_orphans FROM (
      SELECT c.incident_id AS iid FROM incident_attachments c
      UNION ALL SELECT c.incident_id FROM incident_status_history c
      UNION ALL SELECT c.incident_id FROM responder_assignment_history c WHERE c.incident_id IS NOT NULL
    ) x
    WHERE NOT EXISTS (SELECT 1 FROM incident_reports ir WHERE ir.id = x.iid)
      AND NOT EXISTS (SELECT 1 FROM reports r WHERE r.id = x.iid);
    IF v_orphans > 0 THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
        'Incident migration aborted: orphaned child rows reference a non-existent incident (see pre-flight 5.4).';
    END IF;

    -- 6.3a Legacy rows already present, identical, in reports (match by id or reference_number)
    INSERT INTO incident_migration_map (legacy_incident_id, canonical_report_id, resolution)
    SELECT ir.id, MIN(r.id), 'matched_existing'
    FROM incident_reports ir
    LEFT JOIN incident_categories ic ON ic.id = ir.category_id
    JOIN reports r
      ON (r.id = ir.id OR r.reference_number = ir.reference_number)
     AND r.reference_number <=> ir.reference_number
      AND r.user_id <=> ir.user_id
      AND r.category_id <=> ir.category_id
      AND r.incident_type <=> COALESCE(ir.incident_type, ic.name, ir.title, 'General Incident')
      AND r.title <=> ir.title
      AND r.description <=> ir.description
      AND r.latitude <=> ir.latitude
      AND r.longitude <=> ir.longitude
      AND r.address <=> ir.address
      AND r.severity <=> LOWER(ir.severity)
      AND r.status <=> CASE ir.status
        WHEN 'Responding' THEN 'responding' WHEN 'On Scene' THEN 'on_site'
        WHEN 'Resolved' THEN 'resolved' WHEN 'Dismissed' THEN 'dismissed'
        WHEN 'Verified' THEN 'verified' ELSE 'pending' END
      AND r.assigned_to <=> ir.assigned_to
      AND r.verified_by <=> ir.verified_by
      AND r.verified_at <=> ir.verified_at
      AND r.resolved_at <=> ir.resolved_at
      AND r.created_at <=> ir.created_at
      AND r.updated_at <=> ir.updated_at
    WHERE NOT EXISTS (SELECT 1 FROM incident_migration_map m WHERE m.legacy_incident_id = ir.id)
    GROUP BY ir.id;

    -- 6.3b Legacy IDs that are free in reports keep their ORIGINAL id
    INSERT INTO reports (id, reference_number, user_id, category_id, incident_type, title, description,
                         latitude, longitude, address, severity, status, assigned_to,
                         verified_by, verified_at, resolved_at, created_at, updated_at)
    SELECT ir.id, ir.reference_number, ir.user_id, ir.category_id,
           COALESCE(ir.incident_type, ic.name, ir.title, 'General Incident'),
           ir.title, ir.description, ir.latitude, ir.longitude, ir.address,
           LOWER(ir.severity),
           CASE ir.status
             WHEN 'Responding' THEN 'responding' WHEN 'On Scene' THEN 'on_site'
             WHEN 'Resolved'   THEN 'resolved'   WHEN 'Dismissed' THEN 'dismissed'
             WHEN 'Verified'   THEN 'verified'   ELSE 'pending' END,
           ir.assigned_to, ir.verified_by, ir.verified_at, ir.resolved_at,
           ir.created_at, ir.updated_at
    FROM incident_reports ir
    LEFT JOIN incident_categories ic ON ic.id = ir.category_id
    WHERE NOT EXISTS (SELECT 1 FROM incident_migration_map m WHERE m.legacy_incident_id = ir.id)
      AND NOT EXISTS (SELECT 1 FROM reports r WHERE r.id = ir.id);

    INSERT INTO incident_migration_map (legacy_incident_id, canonical_report_id, resolution)
    SELECT ir.id, ir.id, 'same_id'
    FROM incident_reports ir
    JOIN reports r ON r.id = ir.id AND r.reference_number = ir.reference_number
    WHERE NOT EXISTS (SELECT 1 FROM incident_migration_map m WHERE m.legacy_incident_id = ir.id);

    -- 6.3c Legacy IDs that collide with a DIFFERENT incident: copy under a new id
    INSERT INTO reports (reference_number, user_id, category_id, incident_type, title, description,
                         latitude, longitude, address, severity, status, assigned_to,
                         verified_by, verified_at, resolved_at, created_at, updated_at)
    SELECT ir.reference_number, ir.user_id, ir.category_id,
           COALESCE(ir.incident_type, ic.name, ir.title, 'General Incident'),
           ir.title, ir.description, ir.latitude, ir.longitude, ir.address,
           LOWER(ir.severity),
           CASE ir.status
             WHEN 'Responding' THEN 'responding' WHEN 'On Scene' THEN 'on_site'
             WHEN 'Resolved'   THEN 'resolved'   WHEN 'Dismissed' THEN 'dismissed'
             WHEN 'Verified'   THEN 'verified'   ELSE 'pending' END,
           ir.assigned_to, ir.verified_by, ir.verified_at, ir.resolved_at,
           ir.created_at, ir.updated_at
    FROM incident_reports ir
    LEFT JOIN incident_categories ic ON ic.id = ir.category_id
    WHERE NOT EXISTS (SELECT 1 FROM incident_migration_map m WHERE m.legacy_incident_id = ir.id);

    INSERT INTO incident_migration_map (legacy_incident_id, canonical_report_id, resolution)
    SELECT ir.id, r.id, 'reassigned_id'
    FROM incident_reports ir
    JOIN reports r ON r.reference_number = ir.reference_number
    WHERE NOT EXISTS (SELECT 1 FROM incident_migration_map m WHERE m.legacy_incident_id = ir.id);

    -- 6.4 Verify nothing was skipped: every legacy row must have a mapping
    SELECT COUNT(*) INTO v_legacy_count FROM incident_reports;
    SELECT COUNT(*) INTO v_unmapped FROM incident_reports ir
      WHERE NOT EXISTS (SELECT 1 FROM incident_migration_map m WHERE m.legacy_incident_id = ir.id);
    IF v_unmapped > 0 THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
        'Incident migration aborted: one or more legacy incidents could not be mapped. No legacy data was removed.';
    END IF;

    -- 6.4b Verify every mapped row matches ALL migrated fields before touching child FKs.
    SELECT COUNT(*) INTO v_mismatches
    FROM incident_reports ir
    JOIN incident_migration_map m ON m.legacy_incident_id = ir.id
    JOIN reports r ON r.id = m.canonical_report_id
    LEFT JOIN incident_categories ic ON ic.id = ir.category_id
    WHERE NOT (r.reference_number <=> ir.reference_number
      AND r.user_id <=> ir.user_id
      AND r.category_id <=> ir.category_id
      AND r.incident_type <=> COALESCE(ir.incident_type, ic.name, ir.title, 'General Incident')
      AND r.title <=> ir.title
      AND r.description <=> ir.description
      AND r.latitude <=> ir.latitude
      AND r.longitude <=> ir.longitude
      AND r.address <=> ir.address
      AND r.severity <=> LOWER(ir.severity)
      AND r.status <=> CASE ir.status
        WHEN 'Responding' THEN 'responding' WHEN 'On Scene' THEN 'on_site'
        WHEN 'Resolved' THEN 'resolved' WHEN 'Dismissed' THEN 'dismissed'
        WHEN 'Verified' THEN 'verified' ELSE 'pending' END
      AND r.assigned_to <=> ir.assigned_to
      AND r.verified_by <=> ir.verified_by
      AND r.verified_at <=> ir.verified_at
      AND r.resolved_at <=> ir.resolved_at
      AND r.created_at <=> ir.created_at
      AND r.updated_at <=> ir.updated_at);
    IF v_mismatches > 0 THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =
        'Incident migration aborted: mapped record content differs in one or more fields. No child references were repointed; resolve conflicts manually.';
    END IF;

    -- 6.5 Repoint children that still reference incident_reports, one table at a time.
    --     MySQL DDL implicitly commits: take a verified backup and do not assume rollback.
    --     If interrupted between DROP FK and UPDATE, inspect the affected child table manually
    --     before rerunning; this migration is not claimed to be transactionally atomic.

    -- incident_attachments
    SET v_fk = NULL;
    SELECT CONSTRAINT_NAME INTO v_fk FROM information_schema.REFERENTIAL_CONSTRAINTS
      WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'incident_attachments'
        AND REFERENCED_TABLE_NAME = 'incident_reports' LIMIT 1;
    IF v_fk IS NOT NULL THEN
      SET @ddl = CONCAT('ALTER TABLE incident_attachments DROP FOREIGN KEY `', v_fk, '`');
      PREPARE s FROM @ddl; EXECUTE s; DEALLOCATE PREPARE s;
      UPDATE incident_attachments c
        JOIN incident_migration_map m ON m.legacy_incident_id = c.incident_id
        SET c.incident_id = m.canonical_report_id;
    END IF;

    -- incident_status_history
    SET v_fk = NULL;
    SELECT CONSTRAINT_NAME INTO v_fk FROM information_schema.REFERENTIAL_CONSTRAINTS
      WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'incident_status_history'
        AND REFERENCED_TABLE_NAME = 'incident_reports' LIMIT 1;
    IF v_fk IS NOT NULL THEN
      SET @ddl = CONCAT('ALTER TABLE incident_status_history DROP FOREIGN KEY `', v_fk, '`');
      PREPARE s FROM @ddl; EXECUTE s; DEALLOCATE PREPARE s;
      UPDATE incident_status_history c
        JOIN incident_migration_map m ON m.legacy_incident_id = c.incident_id
        SET c.incident_id = m.canonical_report_id;
    END IF;

    -- responder_assignment_history
    SET v_fk = NULL;
    SELECT CONSTRAINT_NAME INTO v_fk FROM information_schema.REFERENTIAL_CONSTRAINTS
      WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'responder_assignment_history'
        AND REFERENCED_TABLE_NAME = 'incident_reports' LIMIT 1;
    IF v_fk IS NOT NULL THEN
      SET @ddl = CONCAT('ALTER TABLE responder_assignment_history DROP FOREIGN KEY `', v_fk, '`');
      PREPARE s FROM @ddl; EXECUTE s; DEALLOCATE PREPARE s;
      UPDATE responder_assignment_history c
        JOIN incident_migration_map m ON m.legacy_incident_id = c.incident_id
        SET c.incident_id = m.canonical_report_id;
    END IF;

  END IF;

  -- 6.6 Ensure each child has its FK to canonical reports (also repairs an interrupted earlier run)
  SELECT COUNT(*) INTO v_has_fk FROM information_schema.REFERENTIAL_CONSTRAINTS
    WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'incident_attachments' AND REFERENCED_TABLE_NAME = 'reports';
  IF v_has_fk = 0 THEN
    ALTER TABLE incident_attachments
      ADD CONSTRAINT fk_incident_attachments_incident FOREIGN KEY (incident_id) REFERENCES reports(id) ON DELETE RESTRICT;
  END IF;

  SELECT COUNT(*) INTO v_has_fk FROM information_schema.REFERENTIAL_CONSTRAINTS
    WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'incident_status_history' AND REFERENCED_TABLE_NAME = 'reports';
  IF v_has_fk = 0 THEN
    ALTER TABLE incident_status_history
      ADD CONSTRAINT fk_incident_history_incident FOREIGN KEY (incident_id) REFERENCES reports(id) ON DELETE RESTRICT;
  END IF;

  SELECT COUNT(*) INTO v_has_fk FROM information_schema.REFERENTIAL_CONSTRAINTS
    WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'responder_assignment_history' AND REFERENCED_TABLE_NAME = 'reports';
  IF v_has_fk = 0 THEN
    ALTER TABLE responder_assignment_history
      ADD CONSTRAINT fk_resp_hist_incident FOREIGN KEY (incident_id) REFERENCES reports(id) ON DELETE RESTRICT;
  END IF;
END$$
DELIMITER ;

CALL sp_geosafe_consolidate_incidents();
DROP PROCEDURE IF EXISTS sp_geosafe_consolidate_incidents;

-- ----------------------------------------------------------------------------
-- 7. Freeze the legacy table (READ-ONLY; NOT a synchronization mechanism)
--    Prevents a second write path. Data stays queryable for verification/rollback.
--    These triggers copy nothing; they only reject writes.
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_incident_reports_freeze_insert;
DROP TRIGGER IF EXISTS trg_incident_reports_freeze_update;
DROP TRIGGER IF EXISTS trg_incident_reports_freeze_delete;
DELIMITER $$
CREATE TRIGGER trg_incident_reports_freeze_insert BEFORE INSERT ON incident_reports
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'incident_reports is a frozen legacy table. Write incidents to reports.';
END$$
CREATE TRIGGER trg_incident_reports_freeze_update BEFORE UPDATE ON incident_reports
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'incident_reports is a frozen legacy table. Update incidents in reports.';
END$$
CREATE TRIGGER trg_incident_reports_freeze_delete BEFORE DELETE ON incident_reports
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'incident_reports is a frozen legacy table and is preserved until migration is verified.';
END$$
DELIMITER ;

-- ----------------------------------------------------------------------------
-- 8. POST-MIGRATION RECONCILIATION (read-only; every result must show 0 / PASS)
-- ----------------------------------------------------------------------------
SELECT
  (SELECT COUNT(*) FROM incident_reports) AS legacy_rows,
  (SELECT COUNT(*) FROM incident_migration_map) AS mapped_rows,
  (SELECT COUNT(*) FROM incident_reports ir WHERE NOT EXISTS
     (SELECT 1 FROM incident_migration_map m WHERE m.legacy_incident_id = ir.id)) AS unmapped_legacy_rows,
  (SELECT COUNT(*) FROM incident_reports ir
     JOIN incident_migration_map m ON m.legacy_incident_id = ir.id
     JOIN reports r ON r.id = m.canonical_report_id
     WHERE NOT (
       r.reference_number <=> ir.reference_number
       AND r.user_id      <=> ir.user_id
       AND r.category_id  <=> ir.category_id
       AND r.incident_type <=> COALESCE(NULLIF(TRIM(ir.title), ''), 'General Incident')
       AND r.title        <=> ir.title
       AND r.description  <=> ir.description
       AND r.latitude     <=> ir.latitude
       AND r.longitude    <=> ir.longitude
       AND r.address      <=> ir.address
       AND r.severity     <=> LOWER(ir.severity)
       AND r.status       <=> CASE ir.status
                                WHEN 'Pending'     THEN 'pending'
                                WHEN 'Verified'    THEN 'verified'
                                WHEN 'Dispatched'  THEN 'dispatched'
                                WHEN 'In Progress' THEN 'in_progress'
                                WHEN 'Resolved'    THEN 'resolved'
                                WHEN 'False Alarm' THEN 'false_alarm'
                                ELSE 'pending'
                              END
       AND r.assigned_to  <=> ir.assigned_to
       AND r.verified_by  <=> ir.verified_by
       AND r.verified_at  <=> ir.verified_at
       AND r.resolved_at  <=> ir.resolved_at
       AND r.created_at   <=> ir.created_at
       AND r.updated_at   <=> ir.updated_at
     )) AS content_mismatches;

-- ----------------------------------------------------------------------------
-- RECOVERY NOTE (DDL implicitly commits; this is NOT an automatic transactional rollback)
--   1. DROP TRIGGER trg_incident_reports_freeze_insert / _update / _delete;
--   2. Child repoint is reversible through the map:
--        ALTER TABLE <child> DROP FOREIGN KEY <fk>;
--        UPDATE <child> c JOIN incident_migration_map m
--          ON m.canonical_report_id = c.incident_id SET c.incident_id = m.legacy_incident_id;
--        ALTER TABLE <child> ADD CONSTRAINT <fk> FOREIGN KEY (incident_id) REFERENCES incident_reports(id);
--      (only for rows whose resolution <> 'matched_existing' where ids differ)
--   3. Do not delete copied rows or reverse child IDs without a verified backup and a reviewed
--      per-row mapping plan. Take and verify a mysqldump before running this migration.
-- ----------------------------------------------------------------------------
