-- ============================================================================
-- GeoSafe Migration 006: Safe Evacuation Center Migration, Routes & Hospitals
-- Target Database: geosafe_db
-- Description:
--   1. Safely adds `capacity` and `available_slots` to `evacuation_centers` without
--      inventing fake capacity values or hardcoding arbitrary numbers.
--   2. Backfills only from existing verified total_capacity/occupancy columns.
--   3. Creates `hospitals` table without fabricated capacity or operational defaults.
--   4. Creates `evacuation_routes` with `is_official_approved DEFAULT 0` (unapproved until verified).
--   5. Creates `evacuation_route_waypoints` with foreign key integrity.
-- Prerequisites: Migration 005 completed.
-- Execution Safety: Strict MySQL 8.4 compatibility, InnoDB, zero mock facilities or routes.
-- ============================================================================

USE geosafe_db;

-- ----------------------------------------------------------------------------
-- 1. Safely Add Capacity and Available Slots to `evacuation_centers`
-- (Zero invented capacities: columns added as NULL, backfilled from verified data only)
-- ----------------------------------------------------------------------------

-- Add capacity column as NULLable first
SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'evacuation_centers' AND COLUMN_NAME = 'capacity');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE evacuation_centers ADD COLUMN capacity INT UNSIGNED DEFAULT NULL AFTER longitude', 
  'SELECT "Column evacuation_centers.capacity already exists" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Backfill capacity strictly from existing total_capacity column where present
UPDATE evacuation_centers 
SET capacity = total_capacity 
WHERE capacity IS NULL AND total_capacity IS NOT NULL;

-- Add available_slots column as NULLable first
SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'evacuation_centers' AND COLUMN_NAME = 'available_slots');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE evacuation_centers ADD COLUMN available_slots INT UNSIGNED DEFAULT NULL AFTER capacity', 
  'SELECT "Column evacuation_centers.available_slots already exists" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Backfill available_slots strictly from verified capacity and occupancy
UPDATE evacuation_centers 
SET available_slots = GREATEST(0, CAST(capacity AS SIGNED) - CAST(COALESCE(current_occupancy, 0) AS SIGNED)) 
WHERE available_slots IS NULL AND capacity IS NOT NULL;

-- Add contact_number
SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'evacuation_centers' AND COLUMN_NAME = 'contact_number');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE evacuation_centers ADD COLUMN contact_number VARCHAR(40) DEFAULT NULL AFTER contact_phone', 
  'SELECT "Column evacuation_centers.contact_number already exists" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

UPDATE evacuation_centers SET contact_number = contact_phone WHERE contact_number IS NULL AND contact_phone IS NOT NULL;

-- Report any unresolved centers where capacity is unknown (does not fabricate numbers)
SELECT 
  id, 
  name, 
  address,
  CASE 
    WHEN capacity IS NULL THEN 'WARNING: Capacity unconfigured - requires official assessment'
    ELSE 'RESOLVED: Capacity verified'
  END AS capacity_status
FROM evacuation_centers;

-- ----------------------------------------------------------------------------
-- 2. Emergency Medical Facilities Table (`hospitals`)
-- (Zero fabricated capacity defaults; neutral 'Under Assessment' initial status)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS hospitals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL UNIQUE,
  address VARCHAR(255) NOT NULL,
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  emergency_contact VARCHAR(60) NOT NULL,
  status ENUM('Operational', 'Full Capacity', 'Critical Supplies', 'Closed', 'Under Assessment') NOT NULL DEFAULT 'Under Assessment',
  capacity INT UNSIGNED NOT NULL,
  available_slots INT UNSIGNED NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_hospitals_status (status),
  INDEX idx_hospitals_coords (latitude, longitude)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 3. Officially Approved Evacuation Routes Table
-- (Strictly defaults to unapproved: is_official_approved = 0 until verified)
-- (Destination center deletion restricted: ON DELETE RESTRICT preserves route safety)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS evacuation_routes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  route_name VARCHAR(150) NOT NULL,
  description TEXT DEFAULT NULL,
  origin_name VARCHAR(150) NOT NULL,
  origin_latitude DECIMAL(10, 8) NOT NULL,
  origin_longitude DECIMAL(11, 8) NOT NULL,
  destination_center_id INT NOT NULL,
  distance_meters INT UNSIGNED DEFAULT NULL,
  estimated_duration_seconds INT UNSIGNED DEFAULT NULL,
  route_type ENUM('pedestrian', 'vehicular', 'accessible') NOT NULL DEFAULT 'pedestrian',
  route_status ENUM('active', 'congested', 'impassable', 'under_review') NOT NULL DEFAULT 'under_review',
  is_official_approved TINYINT(1) NOT NULL DEFAULT 0,
  approval_authority VARCHAR(120) DEFAULT NULL,
  approved_at TIMESTAMP NULL DEFAULT NULL,
  encoded_geometry TEXT DEFAULT NULL,
  created_by INT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_evac_routes_center (destination_center_id),
  INDEX idx_evac_routes_status (route_status),
  INDEX idx_evac_routes_type (route_type),
  INDEX idx_evac_routes_approved (is_official_approved),
  CONSTRAINT fk_evac_routes_center FOREIGN KEY (destination_center_id) REFERENCES evacuation_centers(id) ON DELETE RESTRICT,
  CONSTRAINT fk_evac_routes_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 4. Evacuation Route Waypoints & Hazard Avoidance Landmarks Table
-- (Restricted delete on route: waypoints preserved; routes use route_status = 'impassable')
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS evacuation_route_waypoints (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  route_id INT NOT NULL,
  sequence_order SMALLINT UNSIGNED NOT NULL,
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  instruction VARCHAR(255) DEFAULT NULL,
  landmark_name VARCHAR(120) DEFAULT NULL,
  INDEX idx_route_waypoint (route_id, sequence_order),
  CONSTRAINT fk_route_waypoints_route FOREIGN KEY (route_id) REFERENCES evacuation_routes(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
