-- ============================================================================
-- GeoSafe Migration 008: Security Audit Logs, Broadcast History & Settings Security
-- Target Database: geosafe_db
-- Description:
--   1. Creates `auth_security_logs` table for authentication & credential security audit.
--   2. Creates `emergency_broadcast_logs` table for tracking administrative siren & alert broadcasts.
--   3. Audit-Safe Foreign Keys: Enforces ON DELETE RESTRICT on emergency_broadcast_logs.authorized_by.
--   4. Adds categorization and protection flags to `system_settings`.
-- Prerequisites: Migration 007 completed.
-- Execution Safety: Strict MySQL 8.4 compatibility, InnoDB, zero mock logs.
-- ============================================================================

USE geosafe_db;

-- ----------------------------------------------------------------------------
-- 1. Authentication Security Event Log Table
-- (Restricted deletion: user accounts are deactivated, never physically deleted)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS auth_security_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT DEFAULT NULL,
  attempted_email VARCHAR(160) NOT NULL,
  event_type ENUM(
    'LOGIN_SUCCESS',
    'LOGIN_FAILURE',
    'LOGOUT',
    'PASSWORD_CHANGE',
    'PASSWORD_RESET_REQUESTED',
    'PASSWORD_RESET_COMPLETED',
    'ACCOUNT_SUSPENDED',
    'ACCOUNT_ACTIVATED',
    'UNAUTHORIZED_ACCESS_ATTEMPT'
  ) NOT NULL,
  ip_address VARCHAR(45) NOT NULL,
  user_agent VARCHAR(255) DEFAULT NULL,
  details JSON DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_auth_logs_event (event_type),
  INDEX idx_auth_logs_email (attempted_email),
  INDEX idx_auth_logs_ip (ip_address),
  INDEX idx_auth_logs_created (created_at),
  CONSTRAINT fk_auth_logs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 2. Emergency Broadcast Audit Logs Table
-- (Strict audit preservation: ON DELETE RESTRICT on authorized_by)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS emergency_broadcast_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  broadcast_title VARCHAR(150) NOT NULL,
  broadcast_message TEXT NOT NULL,
  severity ENUM('Low', 'Medium', 'High', 'Critical') NOT NULL,
  target_role VARCHAR(50) DEFAULT 'all',
  target_barangay VARCHAR(100) DEFAULT 'Barangay Bayanan',
  authorized_by INT NOT NULL,
  channels_activated JSON DEFAULT NULL,
  delivery_success_count INT UNSIGNED NOT NULL DEFAULT 0,
  delivery_failure_count INT UNSIGNED NOT NULL DEFAULT 0,
  broadcast_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_broadcast_severity (severity),
  INDEX idx_broadcast_date (broadcast_at),
  INDEX idx_broadcast_authorizer (authorized_by),
  CONSTRAINT fk_broadcast_authorizer FOREIGN KEY (authorized_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 3. Enhance `system_settings` Table with Category & Protection Flags
-- ----------------------------------------------------------------------------
SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS 
  WHERE TABLE_SCHEMA = 'geosafe_db' AND TABLE_NAME = 'system_settings' AND COLUMN_NAME = 'category');
SET @stmt := IF(@col_exists = 0, 
  'ALTER TABLE system_settings ADD COLUMN category ENUM(\'eoc\', \'weather\', \'evacuation\', \'dispatch\', \'system\') NOT NULL DEFAULT \'system\' AFTER setting_key, ADD COLUMN is_protected TINYINT(1) NOT NULL DEFAULT 1 AFTER setting_value, ADD INDEX idx_settings_category (category)', 
  'SELECT "Columns category/is_protected already exist on system_settings" AS status');
PREPARE stmt FROM @stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Update categories for default settings
UPDATE system_settings SET category = 'eoc' WHERE setting_key LIKE 'eoc_%' OR setting_key LIKE 'cdrmo_%';
UPDATE system_settings SET category = 'weather' WHERE setting_key LIKE 'weather_%';
UPDATE system_settings SET category = 'dispatch' WHERE setting_key LIKE 'auto_triage_%';

-- ----------------------------------------------------------------------------
-- 4. Schema-Wide Foreign Key Hardening (Eliminate Destructive CASCADE / SET NULL)
--    - Pre-flight check verifies zero orphaned foreign key references before
--      upgrading constraints (never deletes records).
--    - Replaces any remaining ON DELETE CASCADE / SET NULL with ON DELETE RESTRICT
--      so emergency, family, assignment, notification, and audit history is preserved.
-- ----------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_geosafe_enforce_historical_fk_protection;
DELIMITER $$
CREATE PROCEDURE sp_geosafe_enforce_historical_fk_protection()
BEGIN
  DECLARE v_orphans INT DEFAULT 0;

  -- Pre-flight orphan check across tables being hardened
  SELECT (
    (SELECT COUNT(*) FROM notification_recipients nr WHERE NOT EXISTS (SELECT 1 FROM notifications n WHERE n.id = nr.notification_id)) +
    (SELECT COUNT(*) FROM notification_recipients nr WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.id = nr.user_id)) +
    (SELECT COUNT(*) FROM evacuation_center_facilities f WHERE NOT EXISTS (SELECT 1 FROM evacuation_centers c WHERE c.id = f.center_id)) +
    (SELECT COUNT(*) FROM evacuation_route_waypoints w WHERE NOT EXISTS (SELECT 1 FROM evacuation_routes r WHERE r.id = w.route_id)) +
    (SELECT COUNT(*) FROM reports r WHERE r.assigned_to IS NOT NULL AND NOT EXISTS (SELECT 1 FROM users u WHERE u.id = r.assigned_to)) +
    (SELECT COUNT(*) FROM reports r WHERE r.verified_by IS NOT NULL AND NOT EXISTS (SELECT 1 FROM users u WHERE u.id = r.verified_by)) +
    (SELECT COUNT(*) FROM rescue_requests rr WHERE rr.confirmed_by IS NOT NULL AND NOT EXISTS (SELECT 1 FROM users u WHERE u.id = rr.confirmed_by)) +
    (SELECT COUNT(*) FROM responder_assignment_history h WHERE h.rescue_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM rescue_requests rr WHERE rr.id = h.rescue_id)) +
    (SELECT COUNT(*) FROM responder_assignment_history h WHERE h.incident_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM reports r WHERE r.id = h.incident_id)) +
    (SELECT COUNT(*) FROM notifications n WHERE n.created_by IS NOT NULL AND NOT EXISTS (SELECT 1 FROM users u WHERE u.id = n.created_by)) +
    (SELECT COUNT(*) FROM audit_logs a WHERE a.user_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM users u WHERE u.id = a.user_id)) +
    (SELECT COUNT(*) FROM auth_security_logs s WHERE s.user_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM users u WHERE u.id = s.user_id)) +
    (SELECT COUNT(*) FROM system_settings ss WHERE ss.updated_by IS NOT NULL AND NOT EXISTS (SELECT 1 FROM users u WHERE u.id = ss.updated_by))
  ) INTO v_orphans;

  IF v_orphans > 0 THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'FK hardening halted: orphaned child reference(s) detected. Review and resolve manually before applying ON DELETE RESTRICT.';
  END IF;

  -- 4.1 notification_recipients -> notifications(id) ON DELETE RESTRICT
  IF EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_notif_recip_notif' AND DELETE_RULE <> 'RESTRICT') THEN
    ALTER TABLE notification_recipients DROP FOREIGN KEY fk_notif_recip_notif;
    ALTER TABLE notification_recipients ADD CONSTRAINT fk_notif_recip_notif FOREIGN KEY (notification_id) REFERENCES notifications(id) ON DELETE RESTRICT;
  END IF;

  -- 4.2 notification_recipients -> users(id) ON DELETE RESTRICT
  IF EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_notif_recip_user' AND DELETE_RULE <> 'RESTRICT') THEN
    ALTER TABLE notification_recipients DROP FOREIGN KEY fk_notif_recip_user;
    ALTER TABLE notification_recipients ADD CONSTRAINT fk_notif_recip_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT;
  END IF;

  -- 4.3 evacuation_center_facilities -> evacuation_centers(id) ON DELETE RESTRICT
  IF EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_evac_fac_center' AND DELETE_RULE <> 'RESTRICT') THEN
    ALTER TABLE evacuation_center_facilities DROP FOREIGN KEY fk_evac_fac_center;
    ALTER TABLE evacuation_center_facilities ADD CONSTRAINT fk_evac_fac_center FOREIGN KEY (center_id) REFERENCES evacuation_centers(id) ON DELETE RESTRICT;
  END IF;

  -- 4.4 evacuation_route_waypoints -> evacuation_routes(id) ON DELETE RESTRICT
  IF EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_route_waypoints_route' AND DELETE_RULE <> 'RESTRICT') THEN
    ALTER TABLE evacuation_route_waypoints DROP FOREIGN KEY fk_route_waypoints_route;
    ALTER TABLE evacuation_route_waypoints ADD CONSTRAINT fk_route_waypoints_route FOREIGN KEY (route_id) REFERENCES evacuation_routes(id) ON DELETE RESTRICT;
  END IF;

  -- 4.5 reports.assigned_to & verified_by -> users(id) ON DELETE RESTRICT
  IF EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_reports_assigned' AND DELETE_RULE <> 'RESTRICT') THEN
    ALTER TABLE reports DROP FOREIGN KEY fk_reports_assigned;
    ALTER TABLE reports ADD CONSTRAINT fk_reports_assigned FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE RESTRICT;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_reports_verifier' AND DELETE_RULE <> 'RESTRICT') THEN
    ALTER TABLE reports DROP FOREIGN KEY fk_reports_verifier;
    ALTER TABLE reports ADD CONSTRAINT fk_reports_verifier FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE RESTRICT;
  END IF;

  -- 4.6 rescue_requests.confirmed_by -> users(id) ON DELETE RESTRICT
  IF EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_rescue_confirmed_by' AND DELETE_RULE <> 'RESTRICT') THEN
    ALTER TABLE rescue_requests DROP FOREIGN KEY fk_rescue_confirmed_by;
    ALTER TABLE rescue_requests ADD CONSTRAINT fk_rescue_confirmed_by FOREIGN KEY (confirmed_by) REFERENCES users(id) ON DELETE RESTRICT;
  END IF;

  -- 4.7 responder_assignment_history.rescue_id & incident_id -> ON DELETE RESTRICT
  IF EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_resp_hist_rescue' AND DELETE_RULE <> 'RESTRICT') THEN
    ALTER TABLE responder_assignment_history DROP FOREIGN KEY fk_resp_hist_rescue;
    ALTER TABLE responder_assignment_history ADD CONSTRAINT fk_resp_hist_rescue FOREIGN KEY (rescue_id) REFERENCES rescue_requests(id) ON DELETE RESTRICT;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_resp_hist_incident' AND DELETE_RULE <> 'RESTRICT') THEN
    ALTER TABLE responder_assignment_history DROP FOREIGN KEY fk_resp_hist_incident;
    ALTER TABLE responder_assignment_history ADD CONSTRAINT fk_resp_hist_incident FOREIGN KEY (incident_id) REFERENCES reports(id) ON DELETE RESTRICT;
  END IF;

  -- 4.8 evacuation_routes.created_by -> users(id) ON DELETE RESTRICT
  IF EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_evac_routes_creator' AND DELETE_RULE <> 'RESTRICT') THEN
    ALTER TABLE evacuation_routes DROP FOREIGN KEY fk_evac_routes_creator;
    ALTER TABLE evacuation_routes ADD CONSTRAINT fk_evac_routes_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT;
  END IF;

  -- 4.9 notifications.created_by -> users(id) ON DELETE RESTRICT
  IF EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_notifications_creator' AND DELETE_RULE <> 'RESTRICT') THEN
    ALTER TABLE notifications DROP FOREIGN KEY fk_notifications_creator;
    ALTER TABLE notifications ADD CONSTRAINT fk_notifications_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT;
  END IF;

  -- 4.10 tropical_cyclone_bulletins.published_by -> users(id) ON DELETE RESTRICT
  IF EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_cyclone_publisher' AND DELETE_RULE <> 'RESTRICT') THEN
    ALTER TABLE tropical_cyclone_bulletins DROP FOREIGN KEY fk_cyclone_publisher;
    ALTER TABLE tropical_cyclone_bulletins ADD CONSTRAINT fk_cyclone_publisher FOREIGN KEY (published_by) REFERENCES users(id) ON DELETE RESTRICT;
  END IF;

  -- 4.11 audit_logs.user_id, auth_security_logs.user_id, system_settings.updated_by, users.family_group_id -> ON DELETE RESTRICT
  IF EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_audit_logs_user' AND DELETE_RULE <> 'RESTRICT') THEN
    ALTER TABLE audit_logs DROP FOREIGN KEY fk_audit_logs_user;
    ALTER TABLE audit_logs ADD CONSTRAINT fk_audit_logs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_auth_logs_user' AND DELETE_RULE <> 'RESTRICT') THEN
    ALTER TABLE auth_security_logs DROP FOREIGN KEY fk_auth_logs_user;
    ALTER TABLE auth_security_logs ADD CONSTRAINT fk_auth_logs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_settings_updater' AND DELETE_RULE <> 'RESTRICT') THEN
    ALTER TABLE system_settings DROP FOREIGN KEY fk_settings_updater;
    ALTER TABLE system_settings ADD CONSTRAINT fk_settings_updater FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE RESTRICT;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = 'geosafe_db' AND CONSTRAINT_NAME = 'fk_users_family_group' AND DELETE_RULE <> 'RESTRICT') THEN
    ALTER TABLE users DROP FOREIGN KEY fk_users_family_group;
    ALTER TABLE users ADD CONSTRAINT fk_users_family_group FOREIGN KEY (family_group_id) REFERENCES family_groups(id) ON DELETE RESTRICT;
  END IF;
END$$
DELIMITER ;

CALL sp_geosafe_enforce_historical_fk_protection();
DROP PROCEDURE IF EXISTS sp_geosafe_enforce_historical_fk_protection;

-- ----------------------------------------------------------------------------
-- 5. Append-Only / Tamper-Resistance Triggers on Historical Audit & Security Tables
--    Prevents accidental or unauthorized DELETE of historical audit trails.
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_audit_logs_prevent_delete;
DROP TRIGGER IF EXISTS trg_audit_logs_prevent_update;
DROP TRIGGER IF EXISTS trg_auth_security_logs_prevent_delete;
DROP TRIGGER IF EXISTS trg_auth_security_logs_prevent_update;
DROP TRIGGER IF EXISTS trg_account_status_history_prevent_delete;
DROP TRIGGER IF EXISTS trg_account_status_history_prevent_update;
DROP TRIGGER IF EXISTS trg_incident_status_history_prevent_delete;
DROP TRIGGER IF EXISTS trg_incident_status_history_prevent_update;
DROP TRIGGER IF EXISTS trg_rescue_status_history_prevent_delete;
DROP TRIGGER IF EXISTS trg_rescue_status_history_prevent_update;
DROP TRIGGER IF EXISTS trg_emergency_broadcast_logs_prevent_delete;
DROP TRIGGER IF EXISTS trg_emergency_broadcast_logs_prevent_update;

DELIMITER $$
CREATE TRIGGER trg_audit_logs_prevent_delete BEFORE DELETE ON audit_logs
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Physical deletion of audit_logs records is prohibited to preserve operational accountability.';
END$$

CREATE TRIGGER trg_auth_security_logs_prevent_delete BEFORE DELETE ON auth_security_logs
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Physical deletion of auth_security_logs records is prohibited to preserve security audit trails.';
END$$

CREATE TRIGGER trg_account_status_history_prevent_delete BEFORE DELETE ON account_status_history
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Physical deletion of account_status_history records is prohibited.';
END$$

CREATE TRIGGER trg_incident_status_history_prevent_delete BEFORE DELETE ON incident_status_history
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Physical deletion of incident_status_history records is prohibited.';
END$$

CREATE TRIGGER trg_rescue_status_history_prevent_delete BEFORE DELETE ON rescue_status_history
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Physical deletion of rescue_status_history records is prohibited.';
END$$

CREATE TRIGGER trg_emergency_broadcast_logs_prevent_delete BEFORE DELETE ON emergency_broadcast_logs
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Physical deletion of emergency_broadcast_logs records is prohibited.';
END$$


CREATE TRIGGER trg_audit_logs_prevent_update BEFORE UPDATE ON audit_logs
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Modification of audit_logs records is prohibited; historical records are immutable.';
END$$

CREATE TRIGGER trg_auth_security_logs_prevent_update BEFORE UPDATE ON auth_security_logs
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Modification of auth_security_logs records is prohibited; historical records are immutable.';
END$$

CREATE TRIGGER trg_account_status_history_prevent_update BEFORE UPDATE ON account_status_history
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Modification of account_status_history records is prohibited; historical records are immutable.';
END$$

CREATE TRIGGER trg_incident_status_history_prevent_update BEFORE UPDATE ON incident_status_history
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Modification of incident_status_history records is prohibited; historical records are immutable.';
END$$

CREATE TRIGGER trg_rescue_status_history_prevent_update BEFORE UPDATE ON rescue_status_history
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Modification of rescue_status_history records is prohibited; historical records are immutable.';
END$$

CREATE TRIGGER trg_emergency_broadcast_logs_prevent_update BEFORE UPDATE ON emergency_broadcast_logs
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Modification of emergency_broadcast_logs records is prohibited; historical records are immutable.';
END$$
DELIMITER ;
